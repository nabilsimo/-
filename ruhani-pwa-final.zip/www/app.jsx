import { useState, useEffect, useRef, useCallback, createContext, useContext } from "react";

/* ══════════════════════════════════════════════════════
   THEMES
══════════════════════════════════════════════════════ */
const THEMES = {
  light: {
    bg:"#fdf8f0", card:"#ffffff", card2:"#fef4e4", overlay:"rgba(253,248,240,0.97)",
    gold:"#9b6e0a", goldL:"#7a5408", goldD:"#c9a227",
    bdr:"rgba(155,110,10,0.22)", glow:"rgba(155,110,10,0.12)", fill:"rgba(155,110,10,0.06)",
    text:"#2a1f0a", sub:"#7a6030", dim:"#c8b090",
    sheet:"rgba(0,0,0,0.35)", patternStroke:"rgba(155,110,10,0.15)",
    gradBg:"linear-gradient(160deg,#fdf8f0,#fef6e8,#fdf4e0)",
  },
  dark: {
    bg:"#0c0906", card:"#181209", card2:"#1f1710", overlay:"rgba(12,9,6,0.97)",
    gold:"#c9a227", goldL:"#e8c84a", goldD:"#9b7c1a",
    bdr:"rgba(201,162,39,0.26)", glow:"rgba(201,162,39,0.18)", fill:"rgba(201,162,39,0.07)",
    text:"#f0ddb0", sub:"#9a7c48", dim:"#534020",
    sheet:"rgba(0,0,0,0.65)", patternStroke:"rgba(201,162,39,0.06)",
    gradBg:"linear-gradient(160deg,#100b05,#0c0906,#080604)",
  }
};
const Ctx = createContext({ dark:false, T:THEMES.light, setDark:()=>{} });
const useT = () => useContext(Ctx);

/* ══════════════════════════════════════════════════════
   STORAGE
══════════════════════════════════════════════════════ */
const S = {
  get(k, fb=null){ try{ const v=localStorage.getItem(k); return v!=null?JSON.parse(v):fb; }catch{ return fb; } },
  set(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch{} },
};

/* ══════════════════════════════════════════════════════
   SURAH DATA  [name, startPage, ayahCount]
══════════════════════════════════════════════════════ */
const SD = [
  ["الفاتحة",1,7],["البقرة",2,286],["آل عمران",50,200],["النساء",77,176],["المائدة",106,120],
  ["الأنعام",128,165],["الأعراف",151,206],["الأنفال",177,75],["التوبة",187,129],["يونس",208,109],
  ["هود",221,123],["يوسف",235,111],["الرعد",249,43],["إبراهيم",255,52],["الحجر",262,99],
  ["النحل",267,128],["الإسراء",282,111],["الكهف",293,110],["مريم",305,98],["طه",312,135],
  ["الأنبياء",322,112],["الحج",332,78],["المؤمنون",342,118],["النور",350,64],["الفرقان",359,77],
  ["الشعراء",367,227],["النمل",377,93],["القصص",385,88],["العنكبوت",396,69],["الروم",404,60],
  ["لقمان",411,34],["السجدة",415,30],["الأحزاب",418,73],["سبأ",428,54],["فاطر",434,45],
  ["يس",440,83],["الصافات",446,182],["ص",453,88],["الزمر",458,75],["غافر",467,85],
  ["فصلت",477,54],["الشورى",483,53],["الزخرف",489,89],["الدخان",496,59],["الجاثية",499,37],
  ["الأحقاف",502,35],["محمد",507,38],["الفتح",511,29],["الحجرات",515,18],["ق",518,45],
  ["الذاريات",520,60],["الطور",523,49],["النجم",526,62],["القمر",528,55],["الرحمن",531,78],
  ["الواقعة",534,96],["الحديد",537,29],["المجادلة",542,22],["الحشر",545,24],["الممتحنة",549,13],
  ["الصف",551,14],["الجمعة",553,11],["المنافقون",554,11],["التغابن",556,18],["الطلاق",558,12],
  ["التحريم",560,12],["الملك",562,30],["القلم",564,52],["الحاقة",566,52],["المعارج",568,44],
  ["نوح",570,28],["الجن",572,28],["المزمل",574,20],["المدثر",575,56],["القيامة",577,40],
  ["الإنسان",578,31],["المرسلات",580,50],["النبأ",582,40],["النازعات",583,46],["عبس",585,42],
  ["التكوير",586,29],["الانفطار",587,19],["المطففين",587,36],["الانشقاق",589,25],["البروج",590,22],
  ["الطارق",591,17],["الأعلى",591,19],["الغاشية",592,26],["الفجر",593,30],["البلد",594,20],
  ["الشمس",595,15],["الليل",595,21],["الضحى",596,11],["الشرح",596,8],["التين",597,8],
  ["العلق",597,19],["القدر",598,5],["البينة",598,8],["الزلزلة",599,8],["العاديات",599,11],
  ["القارعة",600,11],["التكاثر",600,8],["العصر",601,3],["الهمزة",601,9],["الفيل",601,5],
  ["قريش",602,4],["الماعون",602,7],["الكوثر",602,3],["الكافرون",603,6],["النصر",603,3],
  ["المسد",603,5],["الإخلاص",604,4],["الفلق",604,5],["الناس",604,6],
];
const SD_IDX=new Map(SD.map((s,i)=>[s[0],i]));

/* ══════════════════════════════════════════════════════
   ADHKAR DATA
══════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════
   أذكار بعد الصلاة + دعاء اليوم
══════════════════════════════════════════════════════ */
const AFTER_PRAYER=[
  {id:"ap1",text:"أَسْتَغْفِرُ اللَّهَ",rep:3},
  {id:"ap2",text:"اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ",rep:1},
  {id:"ap3",text:"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",rep:1},
  {id:"ap4",text:"اللَّهُمَّ لَا مَانِعَ لِمَا أَعْطَيْتَ، وَلَا مُعْطِيَ لِمَا مَنَعْتَ، وَلَا يَنْفَعُ ذَا الْجَدِّ مِنْكَ الْجَدُّ",rep:1},
  {id:"ap5",text:"سُبْحَانَ اللَّهِ",rep:33},
  {id:"ap6",text:"الْحَمْدُ لِلَّهِ",rep:33},
  {id:"ap7",text:"اللَّهُ أَكْبَرُ",rep:33},
  {id:"ap8",text:"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",rep:1},
  {id:"ap9",text:"آيَةُ الْكُرْسِيِّ: ٱللَّهُ لَآ إِلَٰهَ إِلَّا هُوَ ٱلْحَيُّ ٱلْقَيُّومُ ۚ لَا تَأْخُذُهُۥ سِنَةٌ وَلَا نَوْمٌ",rep:1},
];

const DAILY_DUAS=[
  {id:1,title:"دعاء الصباح",text:"اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ"},
  {id:2,title:"دعاء الرزق",text:"اللَّهُمَّ اكْفِنِي بِحَلَالِكَ عَنْ حَرَامِكَ، وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ"},
  {id:3,title:"دعاء العافية",text:"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ"},
  {id:4,title:"دعاء الهداية",text:"اللَّهُمَّ اهْدِنِي فِيمَنْ هَدَيْتَ، وَعَافِنِي فِيمَنْ عَافَيْتَ، وَتَوَلَّنِي فِيمَنْ تَوَلَّيْتَ"},
  {id:5,title:"دعاء القلب",text:"يَا مُقَلِّبَ الْقُلُوبِ، ثَبِّتْ قَلْبِي عَلَى دِينِكَ"},
  {id:6,title:"دعاء الغفران",text:"اللَّهُمَّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ"},
  {id:7,title:"دعاء الأمان",text:"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"},
  {id:8,title:"دعاء العلم",text:"رَبِّ زِدْنِي عِلْمًا، وَارْزُقْنِي فَهْمًا"},
  {id:9,title:"دعاء الصبر",text:"رَبَّنَا أَفْرِغْ عَلَيْنَا صَبْرًا وَثَبِّتْ أَقْدَامَنَا وَانصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ"},
  {id:10,title:"دعاء الجنة",text:"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْجَنَّةَ، وَأَعُوذُ بِكَ مِنَ النَّارِ"},
  {id:11,title:"دعاء التوبة",text:"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، أَسْتَغْفِرُكَ وَأَتُوبُ إِلَيْكَ"},
  {id:12,title:"آية الكرسي دعاء",text:"رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ"},
  {id:13,title:"دعاء الفرج",text:"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْخَيْرَ كُلَّهُ عَاجِلَهُ وَآجِلَهُ مَا عَلِمْتُ مِنْهُ وَمَا لَمْ أَعْلَمْ"},
  {id:14,title:"دعاء المساء",text:"اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ"},
];

const MORNING = [
  {id:1,title:"دعاء الصباح",rep:1,text:"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"},
  {id:2,title:"سيد الاستغفار",rep:1,text:"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ"},
  {id:3,title:"آية الكرسي",rep:1,text:"ٱللَّهُ لَآ إِلَٰهَ إِلَّا هُوَ ٱلۡحَيُّ ٱلۡقَيُّومُۚ لَا تَأۡخُذُهُۥ سِنَةٞ وَلَا نَوۡمٞۚ لَّهُۥ مَا فِي ٱلسَّمَٰوَٰتِ وَمَا فِي ٱلۡأَرۡضِۗ مَن ذَا ٱلَّذِي يَشۡفَعُ عِندَهُۥٓ إِلَّا بِإِذۡنِهِۦۚ يَعۡلَمُ مَا بَيۡنَ أَيۡدِيهِمۡ وَمَا خَلۡفَهُمۡۖ وَلَا يُحِيطُونَ بِشَيۡءٖ مِّنۡ عِلۡمِهِۦٓ إِلَّا بِمَا شَآءَۚ وَسِعَ كُرۡسِيُّهُ ٱلسَّمَٰوَٰتِ وَٱلۡأَرۡضَۖ وَلَا يَـُٔودُهُۥ حِفۡظُهُمَاۚ وَهُوَ ٱلۡعَلِيُّ ٱلۡعَظِيمُ"},
  {id:4,title:"الحماية بالله",rep:3,text:"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"},
  {id:5,title:"الرضا بالله",rep:3,text:"رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا"},
  {id:6,title:"التوكل على الله",rep:7,text:"حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ"},
  {id:7,title:"التسبيح",rep:100,text:"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"},
  {id:8,title:"لا إله إلا الله",rep:10,text:"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"},
  {id:9,title:"دعاء العافية",rep:1,text:"اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ"},
];
const EVENING = [
  {id:1,title:"دعاء المساء",rep:1,text:"أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"},
  {id:2,title:"سيد الاستغفار",rep:1,text:"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي"},
  {id:3,title:"آية الكرسي",rep:1,text:"ٱللَّهُ لَآ إِلَٰهَ إِلَّا هُوَ ٱلۡحَيُّ ٱلۡقَيُّومُۚ لَا تَأۡخُذُهُۥ سِنَةٞ وَلَا نَوۡمٞۚ لَّهُۥ مَا فِي ٱلسَّمَٰوَٰتِ وَمَا فِي ٱلۡأَرۡضِ..."},
  {id:4,title:"الحماية بالله",rep:3,text:"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"},
  {id:5,title:"التوكل على الله",rep:7,text:"حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ"},
  {id:6,title:"المعوذات",rep:3,text:"قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ"},
  {id:7,title:"التسبيح",rep:100,text:"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"},
  {id:8,title:"الاستغفار",rep:3,text:"أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ"},
  {id:9,title:"دعاء النوم",rep:1,text:"بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا"},
];

/* ══════════════════════════════════════════════════════
   PRAYER CONFIG
══════════════════════════════════════════════════════ */
const PRAYERS=["Fajr","Sunrise","Dhuhr","Asr","Maghrib","Isha"];
const PAR={Fajr:"الفجر",Sunrise:"الشروق",Dhuhr:"الظهر",Asr:"العصر",Maghrib:"المغرب",Isha:"العشاء"};
const PICO={Fajr:"🌙",Sunrise:"🌅",Dhuhr:"☀️",Asr:"🌤️",Maghrib:"🌇",Isha:"🌃"};
const nowHM=()=>{const d=new Date();return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");};

/* ══════════════════════════════════════════════════════
   QIBLA MATH
══════════════════════════════════════════════════════ */
const MECCA={lat:21.4225,lng:39.8262};
const rad=d=>d*Math.PI/180;
const qiblaDir=(la,lo)=>{
  const y=Math.sin(rad(MECCA.lng-lo))*Math.cos(rad(MECCA.lat));
  const x=Math.cos(rad(la))*Math.sin(rad(MECCA.lat))-Math.sin(rad(la))*Math.cos(rad(MECCA.lat))*Math.cos(rad(MECCA.lng-lo));
  return((Math.atan2(y,x)*180/Math.PI)+360)%360;
};
const kmMecca=(la,lo)=>{
  const R=6371,dLa=rad(MECCA.lat-la),dLo=rad(MECCA.lng-lo);
  const a=Math.sin(dLa/2)**2+Math.cos(rad(la))*Math.cos(rad(MECCA.lat))*Math.sin(dLo/2)**2;
  return Math.round(R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a)));
};

/* ══════════════════════════════════════════════════════
   SHARED LOCATION + MAJOR CITIES
══════════════════════════════════════════════════════ */
// Major cities fallback [name_ar, lat, lng, tz_offset]
const CITIES = [
  ["مكة المكرمة",21.3891,39.8579,3],["المدينة المنورة",24.5247,39.5692,3],
  ["الرياض",24.6877,46.7219,3],["جدة",21.5433,39.1728,3],["الدمام",26.4207,50.0888,3],
  ["دبي",25.2048,55.2708,4],["أبوظبي",24.4539,54.3773,4],["الكويت",29.3759,47.9774,3],
  ["الدوحة",25.2854,51.5310,3],["مسقط",23.5880,58.3829,4],["البحرين",26.0667,50.5577,3],
  ["عمّان",31.9539,35.9106,2],["بيروت",33.8886,35.4955,2],["دمشق",33.5102,36.2913,2],
  ["القاهرة",30.0444,31.2357,2],["الإسكندرية",31.2001,29.9187,2],["الخرطوم",15.5007,32.5599,2],
  ["تونس",36.8065,10.1815,1],["الجزائر",36.7372,3.0865,1],["الرباط",33.9716,-6.8498,0],
  ["الدار البيضاء",33.5731,-7.5898,0],["طرابلس",32.9020,13.1800,2],["إسطنبول",41.0082,28.9784,3],
  ["أنقرة",39.9334,32.8597,3],["باكستان/كراتشي",24.8608,67.0104,5],["لاهور",31.5497,74.3436,5],
  ["إسلام آباد",33.7294,73.0931,5],["دهلي",28.7041,77.1025,5.5],["جاكرتا",-6.2088,106.8456,7],
  ["كوالالمبور",3.1390,101.6869,8],["لندن",51.5074,-0.1278,0],["باريس",48.8566,2.3522,1],
  ["برلين",52.5200,13.4050,1],["مدريد",40.4168,-3.7038,1],["روما",41.9028,12.4964,1],
  ["نيويورك",40.7128,-74.0060,-5],["لوس أنجلوس",34.0522,-118.2437,-8],
  ["شيكاغو",41.8781,-87.6298,-6],["هيوستن",29.7604,-95.3698,-6],
  ["تورنتو",43.6532,-79.3832,-5],["مونتريال",45.5017,-73.5673,-5],
  ["لاغوس",6.5244,3.3792,1],["نيروبي",-1.2921,36.8219,3],
  ["أديس أبابا",9.0320,38.7625,3],["أكرا",5.6037,-0.1870,0],
  ["جوهانسبرغ",-26.2041,28.0473,2],["مومباي",19.0760,72.8777,5.5],
  ["سيدني",-33.8688,151.2093,10],["ملبورن",-37.8136,144.9631,10],
];

/* ── City picker component (standalone, not inside hook) ── */
function CityPicker({onSelect}){
  const{T}=useT();
  const[search,setSearch]=useState("");
  const filtered=CITIES.filter(([n])=>!search||n.includes(search));
  return(
    <div style={{padding:"10px 14px"}}>
      <p style={{color:T.sub,fontSize:14,marginBottom:10,direction:"rtl",textAlign:"center"}}>اختر مدينتك من القائمة</p>
      <input value={search} onChange={e=>setSearch(e.target.value)}
        placeholder="ابحث عن مدينة..."
        style={{width:"100%",background:T.card2,border:`1px solid ${T.bdr}`,borderRadius:9,
          padding:"8px 12px",color:T.text,fontSize:14,direction:"rtl",marginBottom:8}}/>
      <div style={{maxHeight:340,overflowY:"auto"}}>
        {filtered.map(c=>(
          <div key={c[0]} onClick={()=>onSelect(c)}
            style={{padding:"10px 12px",borderRadius:9,marginBottom:4,cursor:"pointer",
              background:T.card2,border:`1px solid ${T.bdr}`,color:T.text,fontSize:15,direction:"rtl"}}>
            📍 {c[0]}
          </div>
        ))}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════
//  LOCATION SYSTEM — singleton module-level
// ══════════════════════════════════════════════════════
let _geoCache = null;

// Module-level in-progress promise — prevents double GPS requests across tabs
let _detectPromise = null;

const GEO_TTL = 24*3600*1000; // 24 ساعة

async function reverseGeocode(lat, lng, signal){
  try{
    const r = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=ar`,
      {signal, headers:{"Accept-Language":"ar"}, cache:"force-cache"}
    );
    const d = await r.json();
    const a = d.address||{};
    return a.city||a.town||a.municipality||a.suburb||a.county||a.state||"موقعك";
  }catch{ return ""; }
}

async function ipGeoFallback(){
  try{
    const r = await fetch("https://ip-api.com/json/?fields=lat,lon,city&lang=ar", {cache:"force-cache"});
    const d = await r.json();
    if(d.lat&&d.lon) return {lat:d.lat, lng:d.lon, city:d.city||"موقعك", fromIP:true};
  }catch{}
  return null;
}

async function doDetect(skipCache=false){
  // Check cache first (24h)
  if(!skipCache){
    const cached = S.get("geoCache", null);
    if(cached?.ts && (Date.now()-cached.ts < GEO_TTL)){
      _geoCache = cached;
      return {ok:true, data:cached};
    }
  }

  // Try GPS
  if(navigator?.geolocation){
    try{
      const pos = await new Promise((res,rej)=>
        navigator.geolocation.getCurrentPosition(res, rej, {timeout:10000, maximumAge:GEO_TTL})
      );
      const {latitude:lat, longitude:lng} = pos.coords;
      const ctrl = new AbortController();
      const city = await reverseGeocode(lat, lng, ctrl.signal);
      const data = {lat, lng, city:city||"موقعك", ts:Date.now(), source:"gps"};
      S.set("geoCache", data); _geoCache = data;
      return {ok:true, data};
    }catch(e){
      // GPS denied or timed out — try IP fallback
      if(e.code===1 || e.code===2){
        const ipData = await ipGeoFallback();
        if(ipData){
          const data = {...ipData, ts:Date.now(), source:"ip"};
          S.set("geoCache", data); _geoCache = data;
          return {ok:true, data};
        }
        return {ok:false, reason: e.code===1 ? "denied" : "unavailable"};
      }
    }
  }else{
    // No GPS API — try IP
    const ipData = await ipGeoFallback();
    if(ipData){
      const data = {...ipData, ts:Date.now(), source:"ip"};
      S.set("geoCache", data); _geoCache = data;
      return {ok:true, data};
    }
    return {ok:false, reason:"no-geo"};
  }
  return {ok:false, reason:"unavailable"};
}

const LOC_STATUS_MSG = {
  idle:        "جارٍ التحضير…",
  loading:     "جارٍ تحديد موقعك…",
  ok:          null,
  cached:      null,
  denied:      "لم يتم السماح بالوصول للموقع",
  unavailable: "تعذّر تحديد الموقع",
  "no-geo":    "متصفحك لا يدعم GPS",
  manual:      null,
};

function useLocation(onSuccess){
  const [locSt, setLocSt] = useState(()=>{
    const cached = S.get("geoCache", null);
    return cached ? {s:"ok", ...cached} : {s:"idle"};
  });

  // Auto-call onSuccess if we already have cached data
  const onSuccessRef = useRef(onSuccess);
  useEffect(()=>{ onSuccessRef.current = onSuccess; },[onSuccess]);

  useEffect(()=>{
    const cached = S.get("geoCache", null);
    if(cached?.ts && (Date.now()-cached.ts < GEO_TTL)){
      _geoCache = cached;
      // استدعاء onSuccess فوراً من الـ cache بدون طلب GPS
      setTimeout(()=>onSuccessRef.current?.(cached), 0);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);

  const detect = useCallback(async(forceRefresh=false)=>{
    if(forceRefresh){ S.set("geoCache",null); _geoCache=null; _detectPromise=null; }
    if(_detectPromise){ 
      // reuse in-progress detection
      const res = await _detectPromise;
      if(res.ok){ setLocSt({s:"ok",...res.data}); onSuccessRef.current?.(res.data); }
      else setLocSt({s:res.reason||"unavailable"});
      return;
    }
    setLocSt({s:"loading"});
    _detectPromise = doDetect(forceRefresh).finally(()=>{ _detectPromise=null; });
    const res = await _detectPromise;
    if(res.ok){
      setLocSt({s:"ok",...res.data});
      onSuccessRef.current?.(res.data);
    }else{
      setLocSt({s:res.reason||"unavailable"});
    }
  },[]);

  const selectCity=([name,lat,lng,tzOff])=>{
    const data={lat,lng,city:name,ts:Date.now(),source:"manual",tzOff};
    S.set("geoCache",data); _geoCache=data;
    setLocSt({s:"ok",...data});
    onSuccessRef.current?.(data);
  };

  const clearAndRefresh=()=>detect(true);

  return {locSt, detect, selectCity, clearAndRefresh, statusMsg:LOC_STATUS_MSG[locSt.s]||""};
}

/* ══════════════════════════════════════════════════════
   CLAUDE API
══════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════
   QURAN CACHE  (memory + localStorage persistence)
══════════════════════════════════════════════════════ */
const QCache={};

// Load all persisted pages from localStorage into memory cache on startup
(function loadPersistedCache(){
  try{
    const stored=localStorage.getItem("qcache_index");
    if(!stored) return;
    const pages=JSON.parse(stored);
    pages.forEach(n=>{
      try{
        const d=localStorage.getItem("qp_"+n);
        if(d) QCache[n]=JSON.parse(d);
      }catch{}
    });
  }catch{}
})();

function savePageToStorage(n, ayahs){
  try{
    localStorage.setItem("qp_"+n, JSON.stringify(ayahs));
    const stored=localStorage.getItem("qcache_index");
    const idx=stored?JSON.parse(stored):[];
    if(!idx.includes(n)){
      idx.push(n);
      localStorage.setItem("qcache_index", JSON.stringify(idx));
    }
  }catch{}
}

function getCachedCount(){
  try{
    const s=localStorage.getItem("qcache_index");
    return s?JSON.parse(s).length:Object.keys(QCache).length;
  }catch{return Object.keys(QCache).length;}
}

function clearQuranCache(){
  try{
    const s=localStorage.getItem("qcache_index");
    const idx=s?JSON.parse(s):[];
    idx.forEach(n=>localStorage.removeItem("qp_"+n));
    localStorage.removeItem("qcache_index");
    Object.keys(QCache).forEach(k=>delete QCache[k]);
  }catch{}
}

async function callClaude(prompt, maxT=2000){
  const res=await fetch("https://api.anthropic.com/v1/messages",{
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:maxT,
      messages:[{role:"user",content:prompt}]})
  });
  if(!res.ok) throw new Error("API "+res.status);
  const d=await res.json();
  return d.content?.[0]?.text||"";
}
async function fetchPage(n){
  if(QCache[n]) return QCache[n];
  const raw=await callClaude(
    `أنت مساعد قرآني. أعطني آيات الصفحة ${n} من المصحف (مصحف المدينة 604 صفحة).
أجب فقط بـ JSON array بلا أي نص إضافي:
[{"s":رقم_السورة,"n":رقم_الآية,"t":"نص الآية بالرسم العثماني"}]`);
  const m=raw.match(/\[[\s\S]*\]/);
  if(!m) throw new Error("parse");
  const arr=JSON.parse(m[0]);
  if(!arr?.length) throw new Error("empty");
  QCache[n]=arr; return arr;
}
async function fetchTafsir(ayahNum, surahName){
  return callClaude(
    `اكتب تفسيراً مختصراً (3-4 أسطر) للآية ${ayahNum} من سورة ${surahName} باللغة العربية الفصحى البسيطة.
ابدأ مباشرة بالتفسير بدون مقدمة.`,700);
}



/* ══════════════════════════════════════════════════════
   GPS PERMISSION SCREEN
══════════════════════════════════════════════════════ */
function GpsPermissionScreen({onAllow, onManual, T, denied=false}){
  const[asking,setAsking]=useState(false);
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
      justifyContent:"center",padding:"32px 24px",gap:18,textAlign:"center"}}>

      {/* أيقونة نابضة */}
      <div style={{position:"relative",marginBottom:8}}>
        <div style={{width:90,height:90,borderRadius:"50%",
          background:`radial-gradient(circle,${T.fill},transparent)`,
          border:`2px solid ${T.bdr}`,display:"flex",alignItems:"center",justifyContent:"center",
          animation:"pulse 2s ease-in-out infinite"}}>
          <span style={{fontSize:42}}>📍</span>
        </div>
      </div>

      <h2 style={{color:T.text,fontSize:20,fontWeight:"bold",lineHeight:1.5}}>
        {denied?"تم رفض الإذن":"تحديد الموقع"}
      </h2>
      <p style={{color:T.sub,fontSize:14,lineHeight:1.9,maxWidth:280}}>
        {denied
          ?<>رفضت إذن الموقع سابقاً<br/>
            <span style={{color:T.gold,fontWeight:"bold"}}>افتح إعدادات المتصفح</span><br/>
            وامنح الإذن، أو اختر مدينتك يدوياً</>
          :<>يحتاج التطبيق لموقعك لحساب<br/>
            <span style={{color:T.gold,fontWeight:"bold"}}>أوقات الصلاة</span> و
            <span style={{color:T.gold,fontWeight:"bold"}}> اتجاه القبلة</span>
            <br/>بدقة عالية</>
        }
      </p>

      {!denied&&(
        <button onClick={async()=>{
          setAsking(true);
          await onAllow();
          setAsking(false);
        }} disabled={asking} style={{
          width:"100%",maxWidth:280,padding:"14px",borderRadius:14,
          background:`linear-gradient(135deg,${T.gold},${T.goldD})`,
          border:"none",color:"#fff",fontSize:16,cursor:"pointer",fontFamily:"inherit",
          boxShadow:`0 4px 20px ${T.glow}`,
          opacity:asking?0.7:1,transition:"opacity .2s",
          display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
          {asking
            ?<><span style={{display:"inline-block",animation:"spin .7s linear infinite"}}>⏳</span> جارٍ التحديد…</>
            :"📡 السماح بتحديد الموقع"}
        </button>
      )}

      <button onClick={onManual} style={{
        background:"transparent",border:`1px solid ${T.bdr}`,color:T.sub,
        borderRadius:12,padding:"10px 24px",cursor:"pointer",fontSize:14,fontFamily:"inherit"}}>
        🏙️ اختر مدينتك يدوياً
      </button>

      <p style={{color:T.dim,fontSize:11,lineHeight:1.7,maxWidth:260}}>
        موقعك يُستخدم محلياً فقط<br/>ولا يُرسل لأي خادم
      </p>
    </div>
  );
}
/* ══════════════════════════════════════════════════════
   QURAN BACKGROUND DOWNLOADER
══════════════════════════════════════════════════════ */
function useQuranDownloader(){
  const[cached,setCached]=useState(getCachedCount);
  const[downloading,setDownloading]=useState(false);
  const[dlPage,setDlPage]=useState(null);
  const abortRef=useRef(false);
  const TOTAL=604;

  const startDownload=useCallback(async(startFrom=1)=>{
    if(downloading) return;
    abortRef.current=false;
    setDownloading(true);
    for(let p=startFrom;p<=TOTAL;p++){
      if(abortRef.current) break;
      if(!QCache[p]){
        try{
          await fetchPage(p);
          setCached(getCachedCount());
          // small delay between requests to avoid rate limiting
          await new Promise(r=>setTimeout(r,400));
        }catch{
          // skip failed pages, continue
          await new Promise(r=>setTimeout(r,1500));
        }
        setDlPage(p);
      }
    }
    setDownloading(false);
    setDlPage(null);
  },[downloading]);

  const stopDownload=useCallback(()=>{
    abortRef.current=true;
    setDownloading(false);
    setDlPage(null);
  },[]);

  const clearCache=useCallback(()=>{
    stopDownload();
    clearQuranCache();
    setCached(0);
  },[stopDownload]);

  // Pre-fetch next page when reading
  const prefetchPage=useCallback(async(currentPage)=>{
    const next=currentPage+1;
    if(next<=TOTAL&&!QCache[next]){
      try{ await fetchPage(next); setCached(getCachedCount()); }catch{}
    }
  },[]);

  return{cached,downloading,dlPage,startDownload,stopDownload,clearCache,prefetchPage,total:TOTAL};
}

/* ══════════════════════════════════════════════════════
   SHARED ATOMS
══════════════════════════════════════════════════════ */
const globalCss=`
  @import url('https://fonts.googleapis.com/css2?family=Amiri+Quran&family=Amiri:wght@400;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Amiri',serif}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
  @keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
  ::-webkit-scrollbar{width:3px}
  ::-webkit-scrollbar-thumb{border-radius:2px}
  input[type=number]::-webkit-inner-spin-button,
  input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none}
  input[type=number]{-moz-appearance:textfield}
  input,button{font-family:'Amiri',serif}
  button:active{opacity:.72}
  input:focus{outline:none}
  @keyframes slideIn{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}
  @keyframes slideOut{from{opacity:1}to{opacity:0}}
  @keyframes pulse{0%,100%{transform:scale(1);box-shadow:0 0 0 0 rgba(201,162,39,.3)}50%{transform:scale(1.05);box-shadow:0 0 0 12px rgba(201,162,39,0)}}
`;

function Spin({label="جارٍ التحميل…"}){
  const{T}=useT();
  return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:14,padding:"44px 20px"}}>
      <div style={{width:40,height:40,borderRadius:"50%",border:`3px solid ${T.fill}`,borderTop:`3px solid ${T.gold}`,animation:"spin .85s linear infinite"}}/>
      <p style={{color:T.sub,fontSize:14,textAlign:"center",lineHeight:1.7}}>{label}</p>
    </div>
  );
}
function Err({icon="⚠️",msg,retry}){
  const{T}=useT();
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,padding:32,textAlign:"center"}}>
      <div style={{fontSize:44}}>{icon}</div>
      <p style={{color:T.sub,fontSize:15,lineHeight:1.8}}>{msg}</p>
      {retry&&<button onClick={retry} style={{background:T.fill,border:`1px solid ${T.bdr}`,color:T.gold,padding:"8px 24px",borderRadius:10,cursor:"pointer",fontSize:15}}>إعادة المحاولة</button>}
    </div>
  );
}
function HR(){const{T}=useT();return(
  <div style={{display:"flex",alignItems:"center",gap:8,margin:"10px 0"}}>
    <div style={{flex:1,height:1,background:`linear-gradient(to left,${T.bdr},transparent)`}}/>
    <svg width="10" height="10" viewBox="0 0 14 14" fill={T.gold}><polygon points="7,0 8.5,5.5 14,7 8.5,8.5 7,14 5.5,8.5 0,7 5.5,5.5"/></svg>
    <div style={{flex:1,height:1,background:`linear-gradient(to right,${T.bdr},transparent)`}}/>
  </div>
);}
function Sheet({open,onClose,title,children}){
  const{T}=useT();
  if(!open) return null;
  return(
    <div style={{position:"fixed",inset:0,zIndex:50,display:"flex",flexDirection:"column",justifyContent:"flex-end"}}>
      <div style={{position:"absolute",inset:0,background:T.sheet}} onClick={onClose}/>
      <div style={{position:"relative",zIndex:1,background:T.card,borderRadius:"20px 20px 0 0",
        maxHeight:"82vh",display:"flex",flexDirection:"column",animation:"slideUp .28s ease"}}>
        <div style={{padding:"16px 18px 10px",display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0,borderBottom:`1px solid ${T.bdr}`}}>
          <span style={{fontSize:17,color:T.text,fontWeight:"bold"}}>{title}</span>
          <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer",color:T.dim,fontSize:22,lineHeight:1}}>×</button>
        </div>
        <div style={{overflowY:"auto",flex:1}}>{children}</div>
      </div>
    </div>
  );
}

function Corner({v,h}){
  const{T}=useT();
  return(
    <div style={{position:"absolute",zIndex:2,[v]:7,[h]:7,width:16,height:16,opacity:.4,
      borderTop:v==="top"?`1.5px solid ${T.gold}`:"none",borderBottom:v==="bottom"?`1.5px solid ${T.gold}`:"none",
      borderLeft:h==="left"?`1.5px solid ${T.gold}`:"none",borderRight:h==="right"?`1.5px solid ${T.gold}`:"none"}}/>
  );
}


const RECITERS=[
  {id:"ar.alafasy",    name:"مشاري العفاسي"},
  {id:"ar.abdurrahmanas-sudais", name:"عبدالرحمن السديس"},
  {id:"ar.husary",    name:"محمود خليل الحصري"},
  {id:"ar.minshawi",  name:"محمد صديق المنشاوي"},
];

/* ══════════════════════════════════════════════════════
   QURAN READER (full-screen overlay)
══════════════════════════════════════════════════════ */
// Auto-scroll speeds: px per frame (60fps)
const SCROLL_SPEEDS=[0.3,0.7,1.3];
const SPEED_LABELS=["🐢","🚶","🏃"];

function QuranReader({page,onClose,bookmarks,toggleBM,isBM,fontSize:initFontSize,onTafsir,onFontSizeChange,recitation}){
  const{T}=useT();
  const TOTAL=604;
  const[inp,setInp]=useState(String(page));
  const[st,setSt]=useState({s:"loading",ayahs:[]});
  const[curPage,setCurPage]=useState(page);
  const[showBar,setShowBar]=useState(true);
  const[fontSize,setFontSize]=useState(initFontSize||21);

  // Auto-scroll state
  const[autoScroll,setAutoScroll]=useState(false);
  const[speedIdx,setSpeedIdx]=useState(1);
  const autoRef=useRef(false);      // mirror for RAF callback
  const speedRef=useRef(1);
  const rafRef=useRef(null);
  const pauseTimerRef=useRef(null); // resume after touch

  const scrollRef=useRef(null), txRef=useRef(null), barTimer=useRef(null);

  const changeFont=v=>{ const n=Math.max(15,Math.min(32,v)); setFontSize(n); S.set("fontSize",n); if(onFontSizeChange) onFontSizeChange(n); };

  const[pageKey,setPageKey]=useState(0); // للتحريك بين الصفحات
  const load=useCallback(async p=>{
    setSt({s:"loading",ayahs:[]});
    try{
      const ayahs=await fetchPage(p);
      setSt({s:"ok",ayahs});
      setPageKey(k=>k+1);
      setTimeout(()=>{if(scrollRef.current)scrollRef.current.scrollTop=0;},40);
    }catch{setSt({s:"error",ayahs:[]});}
  },[]);

  useEffect(()=>{load(curPage);},[curPage,load]);

  const go=useCallback(p=>{
    const n=Math.max(1,Math.min(TOTAL,parseInt(p)||1));
    setCurPage(n); setInp(String(n)); S.set("lastPage",n);
  },[]);

  const flashBar=()=>{
    setShowBar(true);
    clearTimeout(barTimer.current);
    barTimer.current=setTimeout(()=>setShowBar(false),3000);
  };
  useEffect(()=>{
    barTimer.current=setTimeout(()=>setShowBar(false),3000);
    return()=>clearTimeout(barTimer.current);
  },[]);

  // ── Auto-scroll RAF loop ──
  useEffect(()=>{
    autoRef.current=autoScroll;
    speedRef.current=speedIdx;
  },[autoScroll,speedIdx]);

  useEffect(()=>{
    function tick(){
      if(autoRef.current&&scrollRef.current){
        const el=scrollRef.current;
        const remaining=el.scrollHeight-el.scrollTop-el.clientHeight;
        if(remaining<=2){
          // End of page → go to next automatically
          setCurPage(p=>{
            const next=Math.min(TOTAL,p+1);
            setInp(String(next));
            S.set("lastPage",next);
            return next;
          });
        }else{
          el.scrollTop+=SCROLL_SPEEDS[speedRef.current];
        }
      }
      rafRef.current=requestAnimationFrame(tick);
    }
    rafRef.current=requestAnimationFrame(tick);
    return()=>{
      cancelAnimationFrame(rafRef.current);
      clearTimeout(pauseTimerRef.current);
    };
  },[]);

  const toggleAutoScroll=()=>{
    setAutoScroll(v=>{autoRef.current=!v;return !v;});
  };
  const cycleSpeed=()=>{
    setSpeedIdx(i=>{const n=(i+1)%SCROLL_SPEEDS.length;speedRef.current=n;return n;});
  };

  // Pause auto-scroll on touch, resume after 2s
  const handleTouchStart=e=>{
    txRef.current=e.touches[0].clientX;
    if(autoRef.current){
      autoRef.current=false; // pause
      clearTimeout(pauseTimerRef.current);
      pauseTimerRef.current=setTimeout(()=>{
        if(autoScroll){autoRef.current=true;}
      },2000);
    }
  };
  const handleTouchEnd=e=>{
    if(txRef.current==null)return;
    const d=txRef.current-e.changedTouches[0].clientX;
    if(Math.abs(d)>55){go(curPage+(d>0?1:-1));}
    else flashBar();
    txRef.current=null;
  };

  const groups=[];
  st.ayahs.forEach(a=>{
    const last=groups[groups.length-1];
    if(!last||last.s!==a.s) groups.push({s:a.s,name:SD[a.s-1]?.[0]||"",ayahs:[]});
    groups[groups.length-1].ayahs.push(a);
  });
  const juz=st.ayahs[0]?.juz;

  // التلاوة الصوتية
  const curSurahNum=groups[0]?.s||null;
  const isReciting=recitation&&recitation.currentSurah===curSurahNum;
  const onRecitation=recitation&&curSurahNum?()=>recitation.toggle(curSurahNum):null;

  return(
    <div style={{position:"fixed",inset:0,zIndex:100,display:"flex",flexDirection:"column",
      background:T.gradBg}} onClick={flashBar}>

      {/* ══ نص القرآن — يأخذ كامل الشاشة ══ */}
      <div ref={scrollRef}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        style={{flex:1,overflowY:"auto",padding:"56px 8px 90px",minHeight:0}}>

        {st.s==="loading"&&<Spin label={"جارٍ تحميل الصفحة "+curPage+"…"}/>}
        {st.s==="error"&&<Err icon="📖" msg="تعذّر التحميل" retry={()=>load(curPage)}/>}

        {st.s==="ok"&&(
          <div key={pageKey} style={{direction:"rtl",animation:"fadeUp .35s ease"}}>
            {/* بسملة */}
            {groups[0]?.ayahs[0]?.n===1&&groups[0].s!==9&&groups[0].s!==1&&(
              <div style={{textAlign:"center",marginBottom:14}}>
                <span style={{fontFamily:"'Amiri Quran',serif",fontSize:fontSize+2,color:T.gold,opacity:.9}}>
                  بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ
                </span>
              </div>
            )}
            {groups.map((g,gi)=>(
              <div key={gi}>
                {g.ayahs[0]?.n===1&&(
                  <div style={{textAlign:"center",margin:"2px 0 12px",padding:"5px 14px",
                    background:T.fill,border:`1px solid ${T.bdr}`,borderRadius:10}}>
                    <span style={{fontSize:15,fontWeight:"bold",
                      background:`linear-gradient(135deg,${T.goldL},${T.gold})`,
                      WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
                      ﴾ سورة {g.name} ﴿
                    </span>
                  </div>
                )}
                <p style={{fontFamily:"'Amiri Quran',serif",fontSize:fontSize,lineHeight:2.5,
                  color:T.text,textAlign:"justify",marginBottom:8,direction:"rtl",
                    lineHeight:fontSize<=20?2.6:fontSize<=24?2.4:2.2}}>
                  {g.ayahs.map((a,ai)=>(
                    <span key={ai}>
                      {a.t}{" "}
                      <span onClick={e=>{e.stopPropagation();onTafsir(a,g.name);}}
                        onContextMenu={e=>{e.preventDefault();toggleBM(a);}}
                        style={{display:"inline-flex",alignItems:"center",justifyContent:"center",
                          fontFamily:"'Amiri',serif",fontSize:10,color:T.gold,
                          background:isBM(a)?T.fill:"transparent",
                          border:`1px solid ${T.bdr}`,borderRadius:"50%",
                          width:22,height:22,verticalAlign:"middle",margin:"0 2px",cursor:"pointer",
                          flexShrink:0}}>
                        {a.n}
                      </span>{" "}
                    </span>
                  ))}
                </p>
                {gi<groups.length-1&&<HR/>}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ══ زر رجوع ثابت دائماً + رقم الصفحة ══ */}
      <div style={{position:"absolute",top:0,left:0,right:0,zIndex:10,
        padding:"10px 12px 8px",
        background:"transparent",
        display:"flex",alignItems:"center",justifyContent:"space-between",
        pointerEvents:"none"}}>
        {/* رجوع — دائماً مرئي */}
        <button onClick={e=>{e.stopPropagation();onClose(curPage);}} style={{
          background:T.overlay,border:`1px solid ${T.bdr}`,color:T.gold,
          borderRadius:22,padding:"6px 14px",cursor:"pointer",fontSize:16,
          backdropFilter:"blur(12px)",boxShadow:`0 2px 14px ${T.glow}`,
          pointerEvents:"auto"}}>
          ← رجوع
        </button>
        {/* fullscreen */}
        <button onClick={e=>{e.stopPropagation();
          document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen?.();
        }} style={{
          background:T.overlay,border:`1px solid ${T.bdr}`,color:T.dim,
          borderRadius:18,padding:"6px 10px",cursor:"pointer",fontSize:14,
          backdropFilter:"blur(12px)",pointerEvents:"auto",marginRight:4}}>
          {document.fullscreenElement?"⤡":"⤢"}
        </button>
        {/* رقم الصفحة + شريط تقدم الختمة */}
        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:3,pointerEvents:"none"}}>
          <span style={{color:T.gold,fontSize:13,fontWeight:"bold",
            background:T.overlay,backdropFilter:"blur(10px)",
            border:`1px solid ${T.bdr}`,borderRadius:14,padding:"4px 12px"}}>
            {curPage} / {TOTAL}
          </span>
          <div style={{width:80,height:3,borderRadius:2,background:T.bdr,overflow:"hidden"}}>
            <div style={{width:`${Math.round(curPage/TOTAL*100)}%`,height:"100%",
              background:`linear-gradient(to left,${T.gold},${T.goldD})`,borderRadius:2}}/>
          </div>
        </div>
      </div>

      {/* ══ شريط سفلي — حجم الخط + تمرير تلقائي ══ */}
      <div style={{position:"absolute",bottom:0,left:0,right:0,zIndex:10,
        padding:"8px 14px 14px",
        background:T.overlay,backdropFilter:"blur(12px)",
        borderTop:`1px solid ${T.bdr}`,
        display:"flex",alignItems:"center",justifyContent:"space-between",gap:12}}>

        {/* حجم الخط */}
        <div style={{display:"flex",alignItems:"center",gap:6}}>
          <button onClick={e=>{e.stopPropagation();changeFont(fontSize-2);}} style={{
            background:T.fill,border:`1px solid ${T.bdr}`,color:T.gold,
            borderRadius:8,width:34,height:34,cursor:"pointer",fontSize:20,fontWeight:"bold",
            display:"flex",alignItems:"center",justifyContent:"center"}}>−</button>
          <span style={{color:T.gold,fontSize:13,minWidth:22,textAlign:"center",fontWeight:"bold"}}>{fontSize}</span>
          <button onClick={e=>{e.stopPropagation();changeFont(fontSize+2);}} style={{
            background:T.fill,border:`1px solid ${T.bdr}`,color:T.gold,
            borderRadius:8,width:34,height:34,cursor:"pointer",fontSize:20,fontWeight:"bold",
            display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
        </div>
        {/* تلاوة */}
        {onRecitation&&(
          <div style={{display:"flex",alignItems:"center",gap:4}}>
            <button onClick={e=>{e.stopPropagation();onRecitation();}} style={{
              background:isReciting?T.gold:T.fill,
              border:`1px solid ${isReciting?T.gold:T.bdr}`,
              color:isReciting?"#fff":T.sub,
              borderRadius:8,width:34,height:34,cursor:"pointer",fontSize:16,
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:isReciting?`0 0 10px ${T.glow}`:"none",transition:"all .2s"}}>
              {recitation?.loading&&recitation?.currentSurah===curSurahNum?"⏳":isReciting?"⏹":"🔊"}
            </button>
            {/* اختيار القارئ */}
            <select onChange={e=>{e.stopPropagation();recitation?.setReciter(e.target.value);}}
              value={recitation?.reciter||"ar.alafasy"}
              style={{background:T.card,border:`1px solid ${T.bdr}`,color:T.sub,
                borderRadius:8,fontSize:10,padding:"2px 4px",cursor:"pointer",
                maxWidth:70,direction:"rtl",fontFamily:"inherit"}}
              onClick={e=>e.stopPropagation()}>
              {RECITERS.map(r=>(
                <option key={r.id} value={r.id}>{r.name.split(" ")[1]||r.name}</option>
              ))}
            </select>
          </div>
        )}

        {/* تمرير تلقائي */}
        <div style={{display:"flex",alignItems:"center",gap:5}}>
          <button onClick={e=>{e.stopPropagation();toggleAutoScroll();}} style={{
            background:autoScroll?T.gold:T.fill,
            border:`1px solid ${autoScroll?T.gold:T.bdr}`,
            color:autoScroll?"#fff":T.sub,
            borderRadius:8,width:36,height:36,cursor:"pointer",fontSize:15,
            display:"flex",alignItems:"center",justifyContent:"center",
            boxShadow:autoScroll?`0 0 10px ${T.glow}`:"none",
            transition:"all .2s"}}>{autoScroll?"⏸":"▶"}</button>
          {[["🐢","بطيء"],["🚶","متوسط"],["🏃","سريع"]].map(([ic,lbl],i)=>(
            <button key={i} onClick={e=>{e.stopPropagation();setSpeedIdx(i);speedRef.current=i;}} style={{
              background:speedIdx===i?T.fill:"transparent",
              border:`1.5px solid ${speedIdx===i?T.gold:T.bdr}`,
              color:speedIdx===i?T.gold:T.dim,
              borderRadius:8,padding:"3px 8px",cursor:"pointer",
              display:"flex",flexDirection:"column",alignItems:"center",gap:1,
              transition:"all .15s",minWidth:40}}>
              <span style={{fontSize:15,lineHeight:1}}>{ic}</span>
              <span style={{fontSize:9}}>{lbl}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// Get surah name at a given mushaf page
function getSurahAtPage(page){
  const s=[...SD].reverse().find(([,pg])=>pg<=page);
  return s?`سورة ${s[0]}`:"";
}

/* ══════════════════════════════════════════════════════
   DAILY VERSE
══════════════════════════════════════════════════════ */
const DAILY_VERSES=[
  {s:2,n:286,t:"لَا يُكَلِّفُ ٱللَّهُ نَفۡسًا إِلَّا وُسۡعَهَاۚ",m:"البقرة"},
  {s:3,n:173,t:"حَسۡبُنَا ٱللَّهُ وَنِعۡمَ ٱلۡوَكِيلُ",m:"آل عمران"},
  {s:13,n:28,t:"أَلَا بِذِكۡرِ ٱللَّهِ تَطۡمَئِنُّ ٱلۡقُلُوبُ",m:"الرعد"},
  {s:65,n:3,t:"وَمَن يَتَوَكَّلۡ عَلَى ٱللَّهِ فَهُوَ حَسۡبُهُۥٓ",m:"الطلاق"},
  {s:2,n:152,t:"فَٱذۡكُرُونِيٓ أَذۡكُرۡكُمۡ وَٱشۡكُرُواْ لِي وَلَا تَكۡفُرُونِ",m:"البقرة"},
  {s:94,n:5,t:"فَإِنَّ مَعَ ٱلۡعُسۡرِ يُسۡرًا",m:"الشرح"},
  {s:3,n:139,t:"وَلَا تَهِنُواْ وَلَا تَحۡزَنُواْ وَأَنتُمُ ٱلۡأَعۡلَوۡنَ",m:"آل عمران"},
  {s:40,n:60,t:"ٱدۡعُونِيٓ أَسۡتَجِبۡ لَكُمۡۚ",m:"غافر"},
  {s:57,n:21,t:"سَابِقُوٓاْ إِلَىٰ مَغۡفِرَةٖ مِّن رَّبِّكُمۡ",m:"الحديد"},
  {s:2,n:255,t:"ٱللَّهُ لَآ إِلَٰهَ إِلَّا هُوَ ٱلۡحَيُّ ٱلۡقَيُّومُۚ",m:"البقرة"},
  {s:18,n:10,t:"رَبَّنَآ ءَاتِنَا مِن لَّدُنكَ رَحۡمَةٗ وَهَيِّئۡ لَنَا مِنۡ أَمۡرِنَا رَشَدًا",m:"الكهف"},
  {s:55,n:13,t:"فَبِأَيِّ ءَالَآءِ رَبِّكُمَا تُكَذِّبَانِ",m:"الرحمن"},
  {s:17,n:80,t:"وَقُل رَّبِّ أَدۡخِلۡنِي مُدۡخَلَ صِدۡقٖ وَأَخۡرِجۡنِي مُخۡرَجَ صِدۡقٖ",m:"الإسراء"},
  {s:20,n:114,t:"وَقُل رَّبِّ زِدۡنِي عِلۡمٗا",m:"طه"},
];

function DailyVerse(){
  const{T}=useT();
  const idx = new Date().getDate() % DAILY_VERSES.length;
  const v = DAILY_VERSES[idx];
  return(
    <div style={{background:`linear-gradient(135deg,${T.card2},${T.card})`,
      border:`1px solid ${T.bdr}`,borderRadius:14,padding:"14px 16px",
      animation:"fadeUp .4s ease"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
        <span style={{color:T.gold,fontSize:12,fontWeight:"bold"}}>✨ آية اليوم</span>
        <span style={{color:T.dim,fontSize:11}}>سورة {v.m} • آية {v.n}</span>
      </div>
      <p style={{fontFamily:"'Amiri Quran',serif",fontSize:20,color:T.text,
        direction:"rtl",lineHeight:2.1,textAlign:"center"}}>
        {v.t}
      </p>
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   QURAN TAB  (home screen)
══════════════════════════════════════════════════════ */


/* ══════════════════════════════════════════════════════
   تلاوة صوتية (Alquran.cloud API)
══════════════════════════════════════════════════════ */
// القراء المتاحون

function useRecitation(){
  const[playing,setPlaying]=useState(false);
  const[loading,setLoading]=useState(false);
  const[reciter,setReciter]=useState("ar.alafasy");
  const[currentSurah,setCurrentSurah]=useState(null);
  const audioRef=useRef(null);
  const reciterRef=useRef("ar.alafasy");

  useEffect(()=>{reciterRef.current=reciter;},[reciter]);

  const stop=useCallback(()=>{
    if(audioRef.current){
      audioRef.current.pause();
      audioRef.current.src="";
      audioRef.current=null;
    }
    setPlaying(false);
    setLoading(false);
    setCurrentSurah(null);
  },[]);

  const playSurah=useCallback(async(surahNum)=>{
    stop();
    setLoading(true);
    setCurrentSurah(surahNum);
    try{
      // Alquran.cloud audio API
      const url=`https://cdn.islamic.network/quran/audio-surah/128/${reciterRef.current}/${surahNum}.mp3`;
      const audio=new Audio(url);
      audioRef.current=audio;
      audio.oncanplay=()=>{setLoading(false);setPlaying(true);};
      audio.onended=()=>{setPlaying(false);setCurrentSurah(null);};
      audio.onerror=()=>{setLoading(false);setPlaying(false);setCurrentSurah(null);};
      audio.play().catch(()=>{setLoading(false);});
    }catch{setLoading(false);}
  },[stop]);

  const toggle=useCallback((surahNum)=>{
    if(currentSurah===surahNum&&(playing||loading)){stop();}
    else{playSurah(surahNum);}
  },[currentSurah,playing,loading,stop,playSurah]);

  useEffect(()=>()=>stop(),[stop]);

  return{playing,loading,currentSurah,reciter,setReciter,toggle,stop,RECITERS};
}

/* ══════════════════════════════════════════════════════
   بحث في القرآن
══════════════════════════════════════════════════════ */
function QuranSearch({onGoPage,onClose}){
  const{T}=useT();
  const[q,setQ]=useState("");
  const[results,setResults]=useState([]);
  const[loading,setLoading]=useState(false);
  const abortRef=useRef(null);

  const search=async(query)=>{
    if(!query.trim()||query.length<2){setResults([]);return;}
    abortRef.current?.abort();
    abortRef.current=new AbortController();
    setLoading(true);
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        signal:abortRef.current.signal,
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",max_tokens:1500,
          messages:[{role:"user",content:
            `ابحث في القرآن الكريم عن: "${query}"
أجب فقط بـ JSON array صالح بدون أي نص إضافي أو backticks:
[{"surah":"اسم السورة","ayah":3,"page":45,"text":"نص الآية كاملاً","match":"الكلمة المطابقة"}]
أعطني أفضل 5 نتائج مرتبة حسب الصلة. page يجب أن يكون رقماً صحيحاً بين 1 و604.`
          }]
        })
      });
      const d=await res.json();
      const txt=d.content?.[0]?.text||"";
      const m=txt.match(/\[\s*\{[\s\S]*\}\s*\]/);
      if(m) setResults(JSON.parse(m[0]));
      else setResults([]);
    }catch(e){if(e.name!=="AbortError") setResults([]);}
    finally{setLoading(false);}
  };

  useEffect(()=>{
    const t=setTimeout(()=>search(q),600);
    return()=>clearTimeout(t);
  },[q]);

  return(
    <div style={{position:"fixed",inset:0,zIndex:200,display:"flex",flexDirection:"column",
      background:T.gradBg,animation:"slideIn .2s ease"}}>

      {/* شريط البحث */}
      <div style={{padding:"12px 14px 10px",background:T.overlay,backdropFilter:"blur(12px)",
        borderBottom:`1px solid ${T.bdr}`,display:"flex",alignItems:"center",gap:10}}>
        <button onClick={onClose} style={{background:T.fill,border:`1px solid ${T.bdr}`,
          color:T.gold,borderRadius:9,padding:"6px 12px",cursor:"pointer",fontSize:16,flexShrink:0}}>←</button>
        <input
          autoFocus
          value={q} onChange={e=>setQ(e.target.value)}
          placeholder="ابحث في القرآن… (آية، كلمة، دعاء)"
          style={{flex:1,background:T.card,border:`1px solid ${T.bdr}`,borderRadius:10,
            color:T.text,fontSize:15,padding:"9px 14px",direction:"rtl",fontFamily:"'Amiri',serif",
            outline:"none"}}/>
        {q&&<button onClick={()=>{setQ("");setResults([]);}} style={{
          background:"transparent",border:"none",color:T.dim,fontSize:18,cursor:"pointer"}}>✕</button>}
      </div>

      {/* النتائج */}
      <div style={{flex:1,overflowY:"auto",padding:"8px 12px"}}>
        {loading&&<Spin label="جارٍ البحث…"/>}
        {!loading&&q.length>=2&&results.length===0&&(
          <div style={{textAlign:"center",padding:"40px 16px"}}>
            <p style={{color:T.sub,fontSize:15}}>لا نتائج لـ "{q}"</p>
          </div>
        )}
        {!loading&&q.length<2&&(
          <div style={{textAlign:"center",padding:"40px 16px",direction:"rtl"}}>
            <p style={{fontSize:32,marginBottom:12}}>🔍</p>
            <p style={{color:T.sub,fontSize:14,lineHeight:1.9}}>
              ابحث عن آية أو كلمة أو موضوع<br/>
              <span style={{color:T.dim,fontSize:12}}>مثال: الصبر، آية الكرسي، سورة الكهف</span>
            </p>
          </div>
        )}
        {results.map((r,i)=>(
          <div key={i} onClick={()=>{onGoPage(r.page);onClose();}}
            style={{background:T.card,border:`1px solid ${T.bdr}`,borderRadius:14,
              padding:"14px",marginBottom:9,cursor:"pointer",transition:"all .15s",
              boxShadow:`0 1px 6px ${T.glow}`}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
              <span style={{color:T.gold,fontSize:13,fontWeight:"bold"}}>سورة {r.surah} — آية {r.ayah}</span>
              <span style={{color:T.dim,fontSize:11,background:T.fill,padding:"1px 8px",
                borderRadius:20,border:`1px solid ${T.bdr}`}}>صفحة {r.page}</span>
            </div>
            <p style={{fontFamily:"'Amiri Quran',serif",fontSize:17,color:T.text,
              direction:"rtl",lineHeight:2.2,textAlign:"justify",margin:0}}>
              {r.text}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

function CacheStatusCard({downloader}){
  const{T}=useT();
  const{cached,downloading,dlPage,startDownload,stopDownload,clearCache,total}=downloader;
  const pct=Math.round(cached/total*100);
  const isFull=cached>=total;
  return(
    <div style={{background:T.card,border:`1px solid ${isFull?T.gold:T.bdr}`,borderRadius:12,
      padding:"11px 14px",animation:"fadeUp .3s ease"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
        <div style={{direction:"rtl"}}>
          <span style={{color:isFull?T.gold:T.text,fontSize:13,fontWeight:"bold"}}>
            {isFull?"✅ القرآن محمّل بالكامل":"📥 تخزين القرآن"}
          </span>
          <span style={{color:T.sub,fontSize:12,marginRight:8}}>
            {cached}/{total} صفحة
          </span>
        </div>
        <div style={{display:"flex",gap:6}}>
          {!isFull&&!downloading&&(
            <button onClick={()=>startDownload(1)} style={{
              background:T.fill,border:`1px solid ${T.gold}`,color:T.gold,
              borderRadius:8,padding:"5px 12px",cursor:"pointer",fontSize:12}}>
              ⬇️ تحميل الكل
            </button>
          )}
          {downloading&&(
            <button onClick={stopDownload} style={{
              background:T.fill,border:`1px solid ${T.bdr}`,color:T.sub,
              borderRadius:8,padding:"5px 12px",cursor:"pointer",fontSize:12}}>
              ⏸ إيقاف
            </button>
          )}
          {cached>0&&!downloading&&(
            <button onClick={clearCache} style={{
              background:"transparent",border:`1px solid ${T.bdr}`,color:T.dim,
              borderRadius:8,padding:"5px 10px",cursor:"pointer",fontSize:11}}>
              🗑
            </button>
          )}
        </div>
      </div>
      {/* progress bar */}
      <div style={{height:5,borderRadius:3,background:T.bdr,overflow:"hidden"}}>
        <div style={{width:`${pct}%`,height:"100%",borderRadius:3,
          background:isFull?`linear-gradient(to left,${T.gold},${T.goldD})`:`linear-gradient(to left,${T.goldD},${T.sub})`,
          transition:"width .4s ease"}}/>
      </div>
      {downloading&&dlPage&&(
        <p style={{color:T.dim,fontSize:11,marginTop:4,direction:"rtl"}}>
          جارٍ تحميل الصفحة {dlPage}…
        </p>
      )}
    </div>
  );
}

function QuranTab(){
  const{T}=useT();
  const downloader=useQuranDownloader();
  const[showSearch,setShowSearch]=useState(false);
  const recitation=useRecitation();
  const TOTAL=604;
  const[lastPage,setLastPage]=useState(()=>S.get("lastPage",1));
  const[fontSize,setFontSize]=useState(()=>S.get("fontSize",21));
  const[bookmarks,setBookmarks]=useState(()=>S.get("bookmarks",[])||[]);
  const[readerPage,setReaderPage]=useState(null); // null = home, number = open reader
  const[showIndex,setShowIndex]=useState(false);
  const[showBM,setShowBM]=useState(false);
  const[tafsir,setTafsir]=useState(null);
  const[search,setSearch]=useState("");
  const[streak,setStreak]=useState(()=>{
    const s=S.get("streak",{days:0,last:""});
    const today=new Date().toDateString();
    return s.last===today||s.last===new Date(Date.now()-86400000).toDateString()?s.days:0;
  });

  const openReader=p=>{
    const n=parseInt(p)||lastPage;
    setReaderPage(n);
    // prefetch next page in background
    setTimeout(()=>downloader.prefetchPage(n),1500);
    // Update reading streak
    const today=new Date().toDateString();
    const savedStreak=S.get("streak",{days:0,last:""});
    const yesterday=new Date(Date.now()-86400000).toDateString();
    if(savedStreak.last!==today){
      const newDays=savedStreak.last===yesterday?savedStreak.days+1:1;
      S.set("streak",{days:newDays,last:today});
      setStreak(newDays);
    }
  };
  const closeReader=p=>{ setLastPage(p); S.set("lastPage",p); setReaderPage(null); };

  const toggleBM=useCallback((a)=>{
    const key=`${a.s}-${a.n}`;
    setBookmarks(prev=>{
      const exists=prev.find(b=>b.key===key);
      const next=exists?prev.filter(b=>b.key!==key):[...prev,{key,page:readerPage||lastPage,s:a.s,n:a.n,t:a.t?.slice(0,40)}];
      S.set("bookmarks",next); return next;
    });
  },[readerPage,lastPage]);
  const isBM=useCallback(a=>!!bookmarks.find(b=>b.key===`${a.s}-${a.n}`),[bookmarks]);
  const changeFontSize=v=>{setFontSize(v); S.set("fontSize",v);};

  const openTafsir=useCallback(async(a,surahName)=>{
    setTafsir({loading:true,text:"",a});
    try{
      const txt=await fetchTafsir(a.n,surahName);
      setTafsir({loading:false,text:txt,a});
    }catch{setTafsir({loading:false,text:"تعذّر تحميل التفسير",a});}
  },[]);

  const filteredSurahs=SD.filter(([name],i)=>
    !search||name.includes(search)||String(i+1).includes(search)
  );

  // ── Render full-screen reader ──
  if(readerPage!==null) return(
    <>
      <QuranReader
        page={readerPage} onClose={closeReader}
        bookmarks={bookmarks} toggleBM={toggleBM} isBM={isBM}
        fontSize={fontSize} onTafsir={openTafsir} onFontSizeChange={changeFontSize}
        recitation={recitation}
      />
      <Sheet open={!!tafsir} onClose={()=>setTafsir(null)}
        title={tafsir?.a?`تفسير الآية ${tafsir.a.n} - سورة ${SD[(tafsir.a.s||1)-1]?.[0]||""}`:""}>
        <div style={{padding:"16px 18px"}}>
          {tafsir?.loading?<Spin label="جارٍ تحميل التفسير…"/>:
            <p style={{color:T.text,fontSize:16,lineHeight:2,direction:"rtl",fontFamily:"'Amiri',serif"}}>{tafsir?.text}</p>}
        </div>
      </Sheet>
    </>
  );

  // ── Home screen ──
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",minHeight:0,padding:"10px 12px 8px",gap:10,overflowY:"auto"}}>

      {/* ── Hero: continue reading ── */}
      <div onClick={()=>openReader(lastPage)} style={{
        background:`linear-gradient(135deg,${T.fill},${T.card2})`,
        border:`1px solid ${T.gold}`,borderRadius:16,padding:"18px 20px",
        cursor:"pointer",display:"flex",alignItems:"center",gap:14,
        boxShadow:`0 0 20px ${T.glow}`,transition:"transform .15s",animation:"fadeUp .3s ease"}}
        onMouseEnter={e=>e.currentTarget.style.transform="scale(1.01)"}
        onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}>
        <div style={{fontSize:42,lineHeight:1}}>📖</div>
        <div style={{flex:1,direction:"rtl"}}>
          <p style={{color:T.gold,fontSize:13,marginBottom:3}}>تابع القراءة</p>
          <p style={{color:T.text,fontSize:18,fontWeight:"bold",
            fontFamily:"'Amiri',serif"}}>
            الصفحة {lastPage}
            {SD[0]?" — "+getSurahAtPage(lastPage):""}
          </p>
          <div style={{marginTop:6}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
              <span style={{color:T.sub,fontSize:11}}>{Math.round((lastPage/604)*100)}% من الختمة</span>
              <span style={{color:T.dim,fontSize:11}}>{604-lastPage} صفحة متبقية</span>
            </div>
            <div style={{height:4,borderRadius:2,background:T.bdr,overflow:"hidden"}}>
              <div style={{width:`${Math.round((lastPage/604)*100)}%`,height:"100%",borderRadius:2,
                background:`linear-gradient(to left,${T.gold},${T.goldD})`,transition:"width .5s ease"}}/>
            </div>
          </div>
        </div>
        <div style={{color:T.gold,fontSize:22,opacity:.6}}>←</div>
      </div>

      {/* ── آية اليوم ── */}
      <div onClick={()=>{
        const v=DAILY_VERSES[new Date().getDate()%DAILY_VERSES.length];
        if(v?.s) openReader(SD[v.s-1]?.[1]||1);
      }} style={{cursor:"pointer"}}>
        <DailyVerse/>
      </div>

      {/* ── Font size ── */}
      <div style={{background:T.card,border:`1px solid ${T.bdr}`,borderRadius:12,
        padding:"10px 14px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:10}}>
        <span style={{color:T.sub,fontSize:13,flexShrink:0}}>حجم الخط</span>
        <div style={{flex:1,display:"flex",alignItems:"center",gap:8}}>
          <button onClick={()=>changeFontSize(Math.max(15,fontSize-2))} style={{
            width:28,height:28,borderRadius:7,border:`1px solid ${T.bdr}`,
            background:T.fill,color:T.gold,cursor:"pointer",fontSize:16,lineHeight:1,flexShrink:0}}>−</button>
          <div style={{flex:1,height:4,borderRadius:2,background:T.bdr,position:"relative",cursor:"pointer"}}
            onClick={e=>{
              const rect=e.currentTarget.getBoundingClientRect();
              const pct=(e.clientX-rect.left)/rect.width;
              changeFontSize(Math.round(15+pct*(32-15)));
            }}>
            <div style={{position:"absolute",left:0,top:0,height:"100%",borderRadius:2,
              background:`linear-gradient(to right,${T.goldD},${T.gold})`,
              width:`${((fontSize-15)/(32-15))*100}%`,transition:"width .15s"}}/>
            <div style={{position:"absolute",top:"50%",transform:"translateY(-50%)",
              width:14,height:14,borderRadius:"50%",background:T.gold,border:`2px solid ${T.card}`,
              boxShadow:`0 0 6px ${T.glow}`,
              left:`calc(${((fontSize-15)/(32-15))*100}% - 7px)`,transition:"left .15s"}}/>
          </div>
          <button onClick={()=>changeFontSize(Math.min(32,fontSize+2))} style={{
            width:28,height:28,borderRadius:7,border:`1px solid ${T.bdr}`,
            background:T.fill,color:T.gold,cursor:"pointer",fontSize:16,lineHeight:1,flexShrink:0}}>+</button>
          <span style={{color:T.gold,fontSize:13,fontWeight:"bold",flexShrink:0,minWidth:20,textAlign:"center"}}>{fontSize}</span>
        </div>
      </div>

      {/* ── Streak ── */}
      {streak>0&&(
        <div style={{background:T.card,border:`1px solid ${T.bdr}`,borderRadius:12,
          padding:"9px 14px",display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:20}}>🔥</span>
          <div style={{direction:"rtl"}}>
            <span style={{color:T.gold,fontWeight:"bold",fontSize:14}}>{streak} يوم</span>
            <span style={{color:T.sub,fontSize:12}}> متواصل في القراءة</span>
          </div>
        </div>
      )}

      {/* ── Cache / Download ── */}
      <CacheStatusCard downloader={downloader}/>

      {/* ── بحث ── */}
      {showSearch&&<QuranSearch onGoPage={p=>openReader(p)} onClose={()=>setShowSearch(false)}/>}

      {/* ── Quick actions ── */}
      <div style={{display:"flex",gap:8}}>
        <button onClick={()=>setShowSearch(true)} style={{flex:1,padding:"12px 8px",borderRadius:12,
          background:T.fill,border:`1.5px solid ${T.gold}`,color:T.gold,cursor:"pointer",fontFamily:"inherit",
          display:"flex",flexDirection:"column",alignItems:"center",gap:5}}>
          <span style={{fontSize:24}}>🔍</span>
          <span style={{fontSize:12,fontWeight:"bold"}}>بحث</span>
        </button>
        <button onClick={()=>setShowIndex(true)} style={{flex:1,padding:"12px 8px",borderRadius:12,
          background:T.card,border:`1px solid ${T.bdr}`,color:T.text,cursor:"pointer",
          display:"flex",flexDirection:"column",alignItems:"center",gap:5}}>
          <span style={{fontSize:24}}>☰</span>
          <span style={{fontSize:12,color:T.sub}}>فهرس السور</span>
        </button>
        <button onClick={()=>setShowBM(true)} style={{flex:1,padding:"12px 8px",borderRadius:12,
          background:T.card,border:`1px solid ${T.bdr}`,color:T.text,cursor:"pointer",
          display:"flex",flexDirection:"column",alignItems:"center",gap:5}}>
          <span style={{fontSize:24}}>🔖</span>
          <span style={{fontSize:12,color:T.sub}}>المحفوظات ({bookmarks.length})</span>
        </button>
        <button onClick={()=>openReader(1)} style={{flex:1,padding:"12px 8px",borderRadius:12,
          background:T.card,border:`1px solid ${T.bdr}`,color:T.text,cursor:"pointer",
          display:"flex",flexDirection:"column",alignItems:"center",gap:5}}>
          <span style={{fontSize:24}}>🔢</span>
          <span style={{fontSize:12,color:T.sub}}>من البداية</span>
        </button>
      </div>

      {/* ── Surah Index Sheet ── */}
      <Sheet open={showIndex} onClose={()=>{setShowIndex(false);setSearch("");}} title="فهرس السور">
        <div style={{padding:"10px 14px"}}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث باسم السورة أو رقمها..."
            style={{width:"100%",background:T.card2,border:`1px solid ${T.bdr}`,borderRadius:9,
              padding:"9px 12px",color:T.text,fontSize:15,direction:"rtl",marginBottom:10}}/>
          {filteredSurahs.map(([name,pg,count],i)=>{
            const idx=SD_IDX.get(name)??0;
            return(
              <div key={name} onClick={()=>{openReader(pg);setShowIndex(false);setSearch("");}}
                style={{display:"flex",justifyContent:"space-between",alignItems:"center",
                  padding:"10px 12px",borderRadius:10,marginBottom:4,cursor:"pointer",
                  background:T.card2,border:`1px solid ${T.bdr}`}}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:28,height:28,borderRadius:"50%",background:T.fill,
                    border:`1px solid ${T.bdr}`,display:"flex",alignItems:"center",justifyContent:"center",
                    color:T.gold,fontSize:11,flexShrink:0}}>{idx+1}</div>
                  <span style={{color:T.text,fontSize:16}}>{name}</span>
                </div>
                <span style={{color:T.dim,fontSize:12}}>{count} آية</span>
              </div>
            );
          })}
        </div>
      </Sheet>

      {/* ── Bookmarks Sheet ── */}
      <Sheet open={showBM} onClose={()=>setShowBM(false)} title="الآيات المحفوظة">
        <div style={{padding:"10px 14px"}}>
          {!bookmarks.length&&<p style={{textAlign:"center",color:T.sub,padding:24,fontSize:15}}>اضغط مطولاً على رقم أي آية لحفظها 🔖</p>}
          {bookmarks.map(b=>(
            <div key={b.key} style={{padding:"12px",borderRadius:10,marginBottom:6,
              background:T.card2,border:`1px solid ${T.bdr}`,cursor:"pointer"}}
              onClick={()=>{openReader(b.page);setShowBM(false);}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                <span style={{color:T.gold,fontSize:12}}>سورة {SD[b.s-1]?.[0]} • آية {b.n}</span>
                <button onClick={e=>{e.stopPropagation();toggleBM(b);}} style={{background:"none",border:"none",color:T.dim,cursor:"pointer",fontSize:14}}>✕</button>
              </div>
              <p style={{color:T.text,fontSize:14,direction:"rtl",fontFamily:"'Amiri Quran',serif",lineHeight:1.8}}>{b.t}…</p>
            </div>
          ))}
        </div>
      </Sheet>
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   ADHKAR TAB
══════════════════════════════════════════════════════ */
// Persist adhkar done state — localStorage keyed by date
function loadAdhkarDone(){
  const today=new Date().toDateString();
  const saved=S.get("adhkarDone_"+today,{});
  return saved;
}

// تحديد وقت الذكر حسب الساعة
function getAdhkarMode(){
  const h=new Date().getHours();
  if(h>=4&&h<12) return "morning";
  if(h>=15&&h<20) return "evening";
  return h<4?"evening":"morning";
}

function AdhkarTab(){
  const{T}=useT();
  const[mode,setMode]=useState(getAdhkarMode);
  const[done,setDone]=useState(loadAdhkarDone);
  const[count,setCount]=useState(0);
  const[tasbeehType,setTasbeehType]=useState(0);
  const TASBEEH=["سُبْحَانَ اللَّهِ","الْحَمْدُ لِلَّهِ","اللَّهُ أَكْبَرُ","لَا إِلَهَ إِلَّا اللَّهُ"];
  const TARGET=33;
  const adhkar=mode==="morning"?MORNING:mode==="evening"?EVENING:mode==="after"?AFTER_PRAYER:[];
  const todayDua=DAILY_DUAS[(new Date().getDate()-1)%DAILY_DUAS.length];

  const markDone=id=>{
    const k=`${mode}-${id}`;
    setDone(prev=>{
      const next={...prev,[k]:!prev[k]};
      S.set("adhkarDone_"+new Date().toDateString(), next);
      return next;
    });
  };

  const doneCount=adhkar.filter(a=>done[`${mode}-${a.id}`]).length;
  const pct=Math.round(doneCount/adhkar.length*100);
  const allDone=doneCount===adhkar.length;

  // شارة الوقت
  const h=new Date().getHours();
  const timeLabel=h>=4&&h<12?"🌅 وقت أذكار الصباح":h>=15&&h<20?"🌆 وقت أذكار المساء":null;

  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",minHeight:0}}>

      {/* شارة الوقت */}
      {timeLabel&&(
        <div style={{margin:"8px 12px 0",padding:"5px 12px",borderRadius:20,flexShrink:0,
          background:T.fill,border:`1px solid ${T.gold}`,textAlign:"center"}}>
          <span style={{color:T.gold,fontSize:12,fontWeight:"bold"}}>{timeLabel}</span>
        </div>
      )}

      {/* تبويبات */}
      <div style={{display:"flex",margin:"8px 12px",borderRadius:14,overflow:"hidden",
        border:`1px solid ${T.bdr}`,flexShrink:0}}>
        {[{id:"morning",l:"🌅 الصباح"},{id:"evening",l:"🌆 المساء"},{id:"after",l:"🤲 بعد الصلاة"},{id:"dua",l:"🌿 دعاء اليوم"},{id:"tasbeeh",l:"📿 التسبيح"}].map(m=>(
          <button key={m.id} onClick={()=>setMode(m.id)} style={{
            flex:1,padding:"10px 2px",border:"none",cursor:"pointer",fontSize:13,fontFamily:"inherit",
            background:mode===m.id?T.gold:"transparent",
            color:mode===m.id?"#fff":T.sub,fontWeight:mode===m.id?"bold":"normal",
            borderRight:m.id!=="tasbeeh"?`1px solid ${T.bdr}`:"none",
            transition:"all .2s"}}>{m.l}</button>
        ))}
      </div>

      {mode==="tasbeeh"?(
        <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
          padding:"12px 16px",gap:14,overflowY:"auto"}}>

          {/* اختيار العبارة */}
          <div style={{display:"flex",gap:6,flexWrap:"wrap",justifyContent:"center",width:"100%"}}>
            {TASBEEH.map((t,i)=>(
              <button key={i} onClick={()=>{setTasbeehType(i);setCount(0);}} style={{
                padding:"7px 14px",borderRadius:20,fontFamily:"inherit",
                border:`1.5px solid ${i===tasbeehType?T.gold:T.bdr}`,
                background:i===tasbeehType?T.gold:"transparent",
                color:i===tasbeehType?"#fff":T.sub,
                fontSize:14,cursor:"pointer",transition:"all .2s"}}>{t}</button>
            ))}
          </div>

          {/* دائرة */}
          <div style={{position:"relative",width:200,height:200}}>
            <svg viewBox="0 0 200 200" width={200} height={200}>
              <circle cx={100} cy={100} r={88} fill={T.card} stroke={T.bdr} strokeWidth={3}/>
              <circle cx={100} cy={100} r={88} fill="none"
                stroke={T.gold} strokeWidth={10} strokeLinecap="round"
                strokeDasharray={`${2*Math.PI*88*Math.min(count,TARGET)/TARGET} ${2*Math.PI*88}`}
                transform="rotate(-90 100 100)" style={{transition:"stroke-dasharray .2s ease"}}/>
            </svg>
            <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",
              alignItems:"center",justifyContent:"center"}}>
              <span style={{fontSize:56,fontWeight:"bold",color:T.gold,lineHeight:1,fontFamily:"monospace"}}>{count}</span>
              <span style={{fontSize:13,color:T.sub,marginTop:4}}>/ {TARGET}</span>
            </div>
          </div>

          <p style={{fontFamily:"'Amiri Quran',serif",fontSize:24,color:T.text,
            textAlign:"center",lineHeight:1.8,direction:"rtl"}}>{TASBEEH[tasbeehType]}</p>

          {count>=TARGET&&(
            <div style={{background:T.fill,border:`1px solid ${T.gold}`,borderRadius:14,
              padding:"10px 20px",textAlign:"center",animation:"fadeUp .3s ease"}}>
              <span style={{color:T.gold,fontSize:14,fontWeight:"bold"}}>✅ أتممت {TARGET} — ينتقل للتالي</span>
            </div>
          )}

          <div style={{display:"flex",gap:12,alignItems:"center"}}>
            <button onClick={()=>{
              if(count+1>TARGET){setTasbeehType(t=>(t+1)%TASBEEH.length);setCount(0);if(navigator.vibrate)navigator.vibrate([40,30,40]);}
              else{setCount(c=>c+1);if(navigator.vibrate)navigator.vibrate(15);}
            }} style={{
              width:96,height:96,borderRadius:"50%",
              background:`linear-gradient(135deg,${T.fill},${T.card2})`,
              border:`3px solid ${T.gold}`,color:T.gold,cursor:"pointer",
              boxShadow:`0 0 28px ${T.glow}`,transition:"transform .08s",
              display:"flex",alignItems:"center",justifyContent:"center",
              fontFamily:"'Amiri Quran',serif",fontSize:20}}
              onMouseDown={e=>e.currentTarget.style.transform="scale(.91)"}
              onMouseUp={e=>e.currentTarget.style.transform="scale(1)"}
              onTouchStart={e=>e.currentTarget.style.transform="scale(.91)"}
              onTouchEnd={e=>e.currentTarget.style.transform="scale(1)"}>سبِّح</button>
            <button onClick={()=>setCount(0)} style={{
              padding:"0 20px",borderRadius:20,height:42,fontFamily:"inherit",
              background:"transparent",border:`1px solid ${T.bdr}`,color:T.sub,cursor:"pointer",fontSize:14}}>
              ↺ صفر
            </button>
          </div>
        </div>
      ):mode==="dua"?(
        /* ── دعاء اليوم ── */
        <div style={{flex:1,display:"flex",flexDirection:"column",padding:"12px",gap:12,overflowY:"auto"}}>
          <div style={{background:T.card,border:`2px solid ${T.gold}`,borderRadius:16,
            padding:"20px 16px",textAlign:"center",boxShadow:`0 0 24px ${T.glow}`}}>
            <p style={{color:T.gold,fontSize:12,fontWeight:"bold",marginBottom:6}}>
              دعاء اليوم {new Date().getDate()} — {new Date().toLocaleDateString("ar-SA",{weekday:"long"})}
            </p>
            <p style={{color:T.sub,fontSize:13,fontWeight:"bold",marginBottom:14}}>{todayDua?.title}</p>
            <p style={{fontFamily:"'Amiri Quran',serif",fontSize:20,color:T.text,
              lineHeight:2.4,direction:"rtl",textAlign:"justify",marginBottom:16}}>
              {todayDua?.text}
            </p>
            <button onClick={()=>{
              if(navigator.share){navigator.share({title:todayDua?.title,text:todayDua?.text});}
              else if(navigator.clipboard){navigator.clipboard.writeText(todayDua?.text);}
            }} style={{background:T.fill,border:`1px solid ${T.bdr}`,color:T.sub,
              borderRadius:20,padding:"7px 20px",cursor:"pointer",fontSize:13,fontFamily:"inherit"}}>
              📋 نسخ الدعاء
            </button>
          </div>
          {/* باقي أدعية الأسبوع */}
          <p style={{color:T.dim,fontSize:12,textAlign:"center"}}>أدعية أخرى</p>
          {DAILY_DUAS.filter(d=>d.id!==todayDua?.id).map(d=>(
            <div key={d.id} style={{background:T.card,border:`1px solid ${T.bdr}`,
              borderRadius:12,padding:"12px 14px"}}>
              <p style={{color:T.gold,fontSize:12,fontWeight:"bold",marginBottom:6}}>{d.title}</p>
              <p style={{fontFamily:"'Amiri Quran',serif",fontSize:16,color:T.text,
                lineHeight:2.1,direction:"rtl",textAlign:"justify"}}>{d.text}</p>
            </div>
          ))}
        </div>
      ):(
        <div style={{flex:1,overflowY:"auto",padding:"0 10px 12px"}}>

          {/* شريط التقدم */}
          {adhkar.length>0&&<div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10,
            padding:"8px 12px",background:T.card,borderRadius:12,
            border:`1px solid ${allDone?T.gold:T.bdr}`,
            boxShadow:allDone?`0 0 14px ${T.glow}`:"none",transition:"all .3s"}}>
            <div style={{flex:1,height:7,borderRadius:4,background:T.bdr,overflow:"hidden"}}>
              <div style={{width:`${pct}%`,height:"100%",borderRadius:4,
                background:allDone?`linear-gradient(to left,${T.gold},${T.goldD})`:`linear-gradient(to left,${T.goldD},${T.sub})`,
                transition:"width .4s ease"}}/>
            </div>
            <span style={{color:allDone?T.gold:T.sub,fontSize:12,fontWeight:allDone?"bold":"normal",
              whiteSpace:"nowrap",minWidth:40,textAlign:"left"}}>
              {allDone?"✅ اكتمل":doneCount+"/"+adhkar.length}
            </span>
          </div>}

          {adhkar.map((a,idx)=>{
            const isDone=!!done[`${mode}-${a.id}`];
            return(
              <div key={a.id} style={{
                background:isDone?T.fill:T.card,
                border:`1.5px solid ${isDone?T.gold:T.bdr}`,
                borderRadius:14,marginBottom:9,
                opacity:isDone?0.65:1,transition:"all .25s",
                overflow:"hidden"}}>

                {/* شريط العنوان */}
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
                  padding:"10px 14px 6px",gap:8}}>
                  <div style={{flex:1}}>
                    <span style={{color:T.gold,fontSize:13,fontWeight:"bold"}}>{a.title}</span>
                    {a.rep>1&&(
                      <span style={{marginRight:8,color:T.sub,fontSize:11,background:T.fill,
                        padding:"1px 8px",borderRadius:20,border:`1px solid ${T.bdr}`}}>
                        {a.rep} مرات
                      </span>
                    )}
                  </div>
                  <button onClick={()=>markDone(a.id)} style={{
                    width:40,height:40,borderRadius:"50%",flexShrink:0,
                    border:`2px solid ${isDone?T.gold:T.bdr}`,
                    background:isDone?T.gold:T.fill,color:isDone?"#fff":T.dim,
                    cursor:"pointer",fontSize:18,
                    display:"flex",alignItems:"center",justifyContent:"center",
                    transition:"all .2s",boxShadow:isDone?`0 0 10px ${T.glow}`:"none"}}>
                    {isDone?"✓":"○"}
                  </button>
                </div>

                {/* نص الذكر */}
                <p style={{
                  fontFamily:"'Amiri Quran',serif",
                  fontSize:18,color:T.text,
                  direction:"rtl",lineHeight:2.2,
                  textAlign:"justify",
                  padding:"0 14px 14px",margin:0}}>
                  {a.text}
                </p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}


const AZAN_SEQ=[
  [587,400],[0,150],[659,400],[0,150],[784,600],[0,200],
  [880,800],[0,300],[784,400],[659,400],[0,200],
  [587,400],[0,150],[659,600],[0,200],[784,1000],[0,400],
  [880,400],[784,300],[659,400],[587,600],[0,500],
  [784,400],[0,150],[880,500],[0,150],[988,800],[0,300],
  [880,400],[784,300],[659,600],[0,300],
  [587,400],[0,150],[784,600],[0,200],[880,1200]
];

function playAzanSynth(){
  try{
    const ctx=new (window.AudioContext||window.webkitAudioContext)();
    let t=ctx.currentTime+0.1;
    AZAN_SEQ.forEach(([freq,dur])=>{
      const d=dur/1000;
      if(freq>0){
        const osc=ctx.createOscillator();
        const gain=ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type="sine"; osc.frequency.value=freq;
        gain.gain.setValueAtTime(0,t);
        gain.gain.linearRampToValueAtTime(0.28,t+0.05);
        gain.gain.setValueAtTime(0.28,t+d-0.08);
        gain.gain.linearRampToValueAtTime(0,t+d);
        osc.start(t); osc.stop(t+d);
      }
      t+=d+(freq>0?0.05:0);
    });
    const totalDur=t-ctx.currentTime;
    // Close AudioContext when done to release browser resource limit
    setTimeout(()=>ctx.close().catch(()=>{}), (totalDur+0.5)*1000);
    return totalDur;
  }catch(e){return 0;}
}

// Multiple azan audio sources — synthesis fallback guaranteed
const AZAN_URLS=[
  "https://cdn.islamic.network/mp3/adhan/ar.makkah.mp3",
];

function useAzan(){
  const[playing,setPlaying]=useState(null);
  const playingRef=useRef(null);    // mirror of playing for stable callbacks
  const audioRef=useRef(null);
  const synthTimerRef=useRef(null);

  const _stopInternal=useCallback(()=>{
    if(audioRef.current){audioRef.current.pause();audioRef.current.src="";audioRef.current=null;}
    if(synthTimerRef.current){clearTimeout(synthTimerRef.current);synthTimerRef.current=null;}
    playingRef.current=null;
    setPlaying(null);
  },[]);

  // playAzan is stable ([] deps) — uses refs, not state
  const playAzan=useCallback(async(prayerKey)=>{
    // Toggle off if same prayer is playing
    if(playingRef.current===prayerKey){_stopInternal();return;}
    // Stop previous
    _stopInternal();
    playingRef.current=prayerKey;
    setPlaying(prayerKey);

    // Try real audio (synthesis fallback)
    let audioPlayed=false;
    for(const url of AZAN_URLS){
      try{
        const audio=new Audio();
        audio.preload="none";
        audioRef.current=audio;
        await new Promise((res,rej)=>{
          const tid=setTimeout(()=>rej(new Error("timeout")),6000);
          audio.oncanplay=()=>{clearTimeout(tid);audio.oncanplay=null;res();};
          audio.onerror=()=>{clearTimeout(tid);rej(new Error("load"));};
          audio.src=url; audio.load();
        });
        await audio.play();
        audio.onended=()=>{playingRef.current=null;setPlaying(null);};
        audioPlayed=true;
        break;
      }catch{
        if(audioRef.current){audioRef.current.src="";audioRef.current=null;}
      }
    }
    if(!audioPlayed){
      const dur=playAzanSynth();
      if(dur>0){
        synthTimerRef.current=setTimeout(()=>{playingRef.current=null;setPlaying(null);synthTimerRef.current=null;},(dur+0.5)*1000);
      }else{playingRef.current=null;setPlaying(null);}
    }
  },[_stopInternal]);  // _stopInternal is stable

  const stopAzan=_stopInternal;

  // Cleanup on unmount
  useEffect(()=>()=>_stopInternal(),[_stopInternal]);

  return{playing,playAzan,stopAzan};
}

/* ══════════════════════════════════════════════════════
   PRAYER TAB
══════════════════════════════════════════════════════ */
/* ── Prayer time calculation (local, no external API) ── */
function calcPrayer(lat, lng, date=new Date()){
  // Simplified prayer time calculation using sun position
  const toDeg=r=>r*180/Math.PI;
  const D2R=Math.PI/180;
  const Y=date.getFullYear(), M=date.getMonth()+1, D=date.getDate();
  const JD=367*Y-Math.trunc(7*(Y+Math.trunc((M+9)/12))/4)+Math.trunc(275*M/9)+D+1721013.5;
  const d=JD-2451545.0;
  const g=(357.529+0.98560028*d)%360;
  const q=(280.459+0.98564736*d)%360;
  const L=(q+1.915*Math.sin(D2R*g)+0.020*Math.sin(D2R*2*g))%360;
  const e=23.439-0.00000036*d;
  const RA=toDeg(Math.atan2(Math.cos(D2R*e)*Math.sin(D2R*L),Math.cos(D2R*L)))/15;
  const sindec=Math.sin(D2R*e)*Math.sin(D2R*L);
  const dec=toDeg(Math.asin(sindec));
  const EqT=(q/15-RA+24)%24;
  const UT12=12-EqT-lng/15;
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const ha=p=>{
    const cosH=(-Math.sin(D2R*p)-Math.sin(D2R*lat)*sindec)/(Math.cos(D2R*lat)*Math.cos(D2R*dec));
    if(isNaN(cosH)||Math.abs(cosH)>1) return 0; // polar day/night fallback
    return toDeg(Math.acos(clamp(cosH,-1,1)))/15;
  };
  const fmt=(h)=>{let t=((h%24)+24)%24;return String(Math.floor(t)).padStart(2,"0")+":"+String(Math.floor((t%1)*60)).padStart(2,"0");};
  // Get local timezone offset
  const tzOff = -date.getTimezoneOffset()/60;
  const adj = h => fmt(h + tzOff);
  const fajr  = UT12 - ha(-18);
  const sunrise= UT12 - ha(-0.833);
  const dhuhr = UT12;
  const asrCot = 1/(1+Math.tan(D2R*Math.abs(lat-dec)));
  const asr   = UT12 + (Math.abs(asrCot)<=1 ? toDeg(Math.acos(clamp(asrCot,-1,1)))/15 : 0);
  const maghrib= UT12 + ha(-0.833);
  const isha  = UT12 + ha(-17);
  return {
    Fajr:   adj(fajr),
    Sunrise:adj(sunrise),
    Dhuhr:  adj(dhuhr),
    Asr:    adj(asr),
    Maghrib:adj(maghrib),
    Isha:   adj(isha),
  };
}

function PrayerTab(){
  const{T}=useT();
  // ── كل الـ state/refs أولاً ──
  const[timings,setTimings]=useState(null);
  const[showManualSheet,setShowManualSheet]=useState(false);
  const[notifs,setNotifs]=useState({});
  const[countdown,setCountdown]=useState("");
  const{playing:azanPlaying,playAzan,stopAzan}=useAzan();
  const timingsDataRef=useRef(null); // location data
  const timingsRef=useRef(null);     // prayer timings

  // ── buildTimings قبل useLocation ──
  const buildTimings=useCallback((data)=>{
    timingsDataRef.current=data;
    const t=calcPrayer(data.lat, data.lng);
    const n=nowHM();
    const full={...t, city:data.city||"موقعك",
      next:PRAYERS.find(p=>t[p]>n)||PRAYERS[0],
      lat:data.lat, lng:data.lng};
    timingsRef.current=full;
    setTimings(full);
  },[]);

  // ── useLocation بعد buildTimings مباشرة ──
  const{locSt,detect,selectCity,clearAndRefresh,statusMsg}=useLocation(buildTimings);

  // ── useEffects بعد كل الـ state ──
  useEffect(()=>{
    const cached=S.get("geoCache",null);
    if(cached) detect();
  },[detect]);

  useEffect(()=>{
    if((locSt.s==="ok"||locSt.s==="cached")&&locSt.lat) buildTimings(locSt);
  },[locSt.lat,locSt.lng,buildTimings]);

  // ── عداد تنازلي — يعمل كل ثانية ──
  useEffect(()=>{
    const tick=()=>{
      if(!timingsRef.current) return;
      const now=new Date();
      const hm=String(now.getHours()).padStart(2,"0")+":"+String(now.getMinutes()).padStart(2,"0");
      const pad=n=>String(n).padStart(2,"0");
      const T2=timingsRef.current;
      const nextP=PRAYERS.find(p=>T2[p]>hm)||PRAYERS[0];
      // تحديث next في timings
      setTimings(prev=>prev&&prev.next!==nextP?{...prev,next:nextP}:prev);
      // العداد
      const[ph,pm]=T2[nextP].split(":").map(Number);
      let diff=ph*60+pm-(now.getHours()*60+now.getMinutes());
      if(diff<0) diff+=24*60;
      const h=Math.floor(diff/60), m=diff%60, s=59-now.getSeconds();
      setCountdown(`${h?pad(h)+":":""}${pad(m)}:${pad(s)}`);
    };
    tick();
    const id=setInterval(tick,1000);
    return()=>clearInterval(id);
  },[]);

  // ── نظام التنبيه بالأذان ──
  const azan_timers=useRef({});

  const clearAllAzanTimers=useCallback(()=>{
    Object.values(azan_timers.current).forEach(id=>clearTimeout(id));
    azan_timers.current={};
  },[]);

  const scheduleAzan=useCallback(async(prayer,timeStr)=>{
    // طلب إذن الإشعارات
    if(Notification.permission!=="granted"){
      const perm=await Notification.requestPermission();
      if(perm!=="granted"){
        alert("يرجى السماح بالإشعارات من إعدادات المتصفح لتفعيل تنبيه الأذان");
        return false;
      }
    }
    // إزالة المؤقت القديم لهذه الصلاة
    if(azan_timers.current[prayer]) clearTimeout(azan_timers.current[prayer]);

    const[h,m]=timeStr.split(":").map(Number);
    const now=new Date();
    const target=new Date();
    target.setHours(h,m,0,0);
    if(target<=now) target.setDate(target.getDate()+1);
    const delay=target-now;

    const NAMES={Fajr:"الفجر",Sunrise:"الشروق",Dhuhr:"الظهر",Asr:"العصر",Maghrib:"المغرب",Isha:"العشاء"};
    azan_timers.current[prayer]=setTimeout(()=>{
      // إشعار أذان
      try{
        new Notification(`🕌 حان وقت صلاة ${NAMES[prayer]||prayer}`,{
          body:`وقت الصلاة: ${timeStr}`,
          icon:"/icons/icon-192.png",
          badge:"/icons/icon-96.png",
          vibrate:[200,100,200,100,200],
          tag:`azan-${prayer}`,
          requireInteraction:true,
        });
      }catch(e){}
      // تحديث state
      setNotifs(prev=>({...prev,[prayer]:false})); // reset toggle
    },delay);

    setNotifs(prev=>({...prev,[prayer]:true}));
    return true;
  },[]);

  const cancelAzan=useCallback((prayer)=>{
    if(azan_timers.current[prayer]){
      clearTimeout(azan_timers.current[prayer]);
      delete azan_timers.current[prayer];
    }
    setNotifs(prev=>({...prev,[prayer]:false}));
  },[]);

  const toggleAzan=useCallback(async(prayer,timeStr)=>{
    if(notifs[prayer]) cancelAzan(prayer);
    else await scheduleAzan(prayer,timeStr);
  },[notifs,cancelAzan,scheduleAzan]);

  // تنظيف عند إلغاء التحميل
  useEffect(()=>()=>clearAllAzanTimers(),[clearAllAzanTimers]);



  const cancelNotif=p=>{
    if(notifs[p]){clearTimeout(notifs[p]);setNotifs(prev=>{const n={...prev};delete n[p];return n;});}
  };

  const isLoading = locSt.s==="loading" && !timings;
  const activeAzanCount=Object.values(notifs).filter(Boolean).length;
  const showGpsScreen = (locSt.s==="idle"||locSt.s==="denied"||locSt.s==="unavailable"||locSt.s==="no-geo") && !timings;
  // showLocError removed — handled by GpsPermissionScreen
  const today = new Date().toLocaleDateString("ar-SA",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
  const hijriToday = new Date().toLocaleDateString("ar-SA-u-ca-islamic",{day:"numeric",month:"long",year:"numeric"});

  return(
    <div style={{flex:1,overflowY:"auto",padding:"10px 12px 8px"}}>

      {/* location card */}
      <div style={{background:T.card,border:`1px solid ${T.bdr}`,borderRadius:13,
        padding:"11px 16px",display:"flex",justifyContent:"space-between",alignItems:"center",
        boxShadow:`0 0 14px ${T.glow}`,marginBottom:10,animation:"fadeUp .3s ease"}}>
        <div style={{direction:"rtl"}}>
          <p style={{color:T.text,fontSize:14,fontWeight:"bold"}}>
            📍 {timings?.city || (locSt.s==="loading"?"جارٍ التحديد…":"غير محدد")}
            {locSt.source==="ip"&&<span style={{color:T.dim,fontSize:10,marginRight:5}}>(IP)</span>}
            {locSt.source==="manual"&&<span style={{color:T.dim,fontSize:10,marginRight:5}}>(يدوي)</span>}
          </p>
          <p style={{color:T.sub,fontSize:12,marginTop:1}}>{today}</p>
          <p style={{color:T.dim,fontSize:11,marginTop:1}}>{hijriToday}</p>
        </div>
        <button onClick={()=>setShowManualSheet(true)} style={{
          background:T.fill,border:`1px solid ${T.bdr}`,color:T.gold,
          borderRadius:9,padding:"6px 12px",cursor:"pointer",fontSize:12,flexShrink:0}}>
          تغيير 📍
        </button>
      </div>

      {isLoading && <Spin label={statusMsg||"جارٍ تحديد موقعك…"}/>}
      {showGpsScreen && (
        <GpsPermissionScreen T={T}
          denied={locSt.s==="denied"||locSt.s==="no-geo"}
          onAllow={clearAndRefresh}
          onManual={()=>setShowManualSheet(true)}/>
      )}
      {/* location error shown via GpsPermissionScreen above */}

      {timings&&(
        <div style={{margin:"0 0 6px",padding:"7px 12px",borderRadius:12,flexShrink:0,
          background:activeAzanCount>0?T.fill:"transparent",
          border:`1px solid ${activeAzanCount>0?T.gold:T.bdr}`,
          display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}}>
          <span style={{color:activeAzanCount>0?T.gold:T.dim,fontSize:12,fontWeight:"bold"}}>
            {activeAzanCount>0?`🔔 ${activeAzanCount} تنبيهات مفعَّلة`:"🔕 لا تنبيهات"}
          </span>
          <div style={{display:"flex",gap:5}}>
            <button onClick={async()=>{for(const p of ["Fajr","Dhuhr","Asr","Maghrib","Isha"]) await scheduleAzan(p,timings[p]);}}
              style={{background:T.fill,border:`1px solid ${T.gold}`,color:T.gold,
                borderRadius:8,padding:"4px 10px",cursor:"pointer",fontSize:11,fontFamily:"inherit"}}>
              تفعيل الكل
            </button>
            {activeAzanCount>0&&(
              <button onClick={()=>["Fajr","Dhuhr","Asr","Maghrib","Isha"].forEach(p=>cancelAzan(p))}
                style={{background:"transparent",border:`1px solid ${T.bdr}`,color:T.sub,
                  borderRadius:8,padding:"4px 8px",cursor:"pointer",fontSize:11,fontFamily:"inherit"}}>
                إلغاء الكل
              </button>
            )}
          </div>
        </div>
      )}
      {timings && (
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {PRAYERS.map(p=>{
            const on=p===timings.next, hasN=!!notifs[p];
            return(
              <div key={p} style={{display:"flex",alignItems:"center",justifyContent:"space-between",
                padding:"11px 14px",borderRadius:12,position:"relative",
                background:on?`linear-gradient(135deg,${T.fill},${T.card2})`:T.card,
                border:`${on?"2px":"1px"} solid ${on?T.gold:T.bdr}`,
                boxShadow:on?`0 0 20px ${T.glow},0 2px 12px ${T.glow}`:"none",
                transform:on?"scale(1.01)":"scale(1)",
                transition:"transform .2s",animation:"fadeUp .4s ease"}}>
                {on&&<div style={{position:"absolute",top:5,right:10,display:"flex",gap:5,alignItems:"center"}}>
                  <span style={{background:T.gold,color:"#fff",fontSize:10,padding:"1px 8px",borderRadius:20,fontWeight:"bold"}}>التالية</span>
                  {countdown&&<span style={{color:T.gold,fontSize:10,fontFamily:"monospace",opacity:.85}}>{countdown}</span>}
                </div>}
                <div style={{display:"flex",alignItems:"center",gap:9}}>
                  <span style={{fontSize:18}}>{PICO[p]}</span>
                  <span style={{fontSize:16,color:on?T.gold:T.text}}>{PAR[p]}</span>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontSize:17,letterSpacing:1,color:on?T.gold:T.sub,fontFamily:"monospace"}}>{timings[p]}</span>
                  <button onClick={()=>playAzan(p)} title="استمع للأذان" style={{
                    background:azanPlaying===p?T.fill:"transparent",border:`1px solid ${azanPlaying===p?T.gold:T.bdr}`,
                    borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:15,
                    color:azanPlaying===p?T.gold:T.dim,display:"flex",alignItems:"center",justifyContent:"center"
                  }}>{azanPlaying===p?"🔊":"🔈"}</button>
                  <button onClick={()=>toggleAzan(p,timings[p])} style={{
                    background:hasN?T.fill:"transparent",border:`1px solid ${hasN?T.gold:T.bdr}`,
                    borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:14,
                    color:hasN?T.gold:T.dim,display:"flex",alignItems:"center",justifyContent:"center"
                  }}>{hasN?"🔔":"🔕"}</button>
                </div>
              </div>
            );
          })}
          <p style={{textAlign:"center",color:T.dim,fontSize:11,padding:"4px 16px",lineHeight:1.7}}>
            الأوقات محسوبة محلياً • 🔈 أذان • 🔕 تنبيه
          </p>
        </div>
      )}

      {/* Manual city sheet */}
      <Sheet open={showManualSheet} onClose={()=>setShowManualSheet(false)} title="اختر موقعك">
        <div style={{padding:"10px 14px"}}>
          <button onClick={()=>{S.set("geoCache",null);detect();setShowManualSheet(false);}} style={{
            width:"100%",padding:"10px",marginBottom:10,borderRadius:10,
            background:T.fill,border:`1px solid ${T.gold}`,color:T.gold,
            cursor:"pointer",fontSize:14}}>
            📡 تحديد الموقع تلقائياً (GPS)
          </button>
          <CityPicker onSelect={c=>{selectCity(c);setShowManualSheet(false);}}/>
        </div>
      </Sheet>
    </div>
  );
}


/* ══════════════════════════════════════════════════════
   MOSQUE MAP COMPONENT
══════════════════════════════════════════════════════ */
function MosqueMap({lat, lng}){
  const{T}=useT();  // use context instead of prop
  const mapRef=useRef(null);
  const mapInstRef=useRef(null);
  const markersRef=useRef([]);  // track all mosque markers for cleanup
  const[mosques,setMosques]=useState([]);
  const[loading,setLoading]=useState(true);
  const[mapStatus,setMapStatus]=useState("loading"); // loading|ready|error
  const[fetchError,setFetchError]=useState(null);

  // Load Leaflet CSS+JS dynamically (once)
  useEffect(()=>{
    if(window.L){setMapStatus("ready");return;}
    const link=document.createElement("link");
    link.rel="stylesheet";
    link.href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css";
    if(!document.querySelector('link[href*="leaflet"]')) document.head.appendChild(link);
    const script=document.createElement("script");
    script.src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js";
    script.onload=()=>setMapStatus("ready");
    script.onerror=()=>setMapStatus("error");
    document.head.appendChild(script);
    return()=>{/* CSS/JS stay loaded globally */};
  },[]);

  // Destroy map on unmount to prevent "already initialized" error
  useEffect(()=>{
    return()=>{
      if(mapInstRef.current){
        mapInstRef.current.remove();
        mapInstRef.current=null;
        markersRef.current=[];
      }
    };
  },[]);

  // Fetch mosques (with AbortController)
  useEffect(()=>{
    if(!lat||!lng) return;
    const ctrl=new AbortController();
    setLoading(true); setFetchError(null);
    const query=`[out:json][timeout:15];(node["amenity"="place_of_worship"]["religion"="muslim"](around:3000,${lat},${lng});way["amenity"="place_of_worship"]["religion"="muslim"](around:3000,${lat},${lng}););out center 20;`;
    fetch("https://overpass-api.de/api/interpreter",{method:"POST",body:query,signal:ctrl.signal})
      .then(r=>r.json())
      .then(d=>{
        const R=111320;
        const list=(d.elements||[]).map(e=>{
          const mlat=e.lat||e.center?.lat, mlng=e.lon||e.center?.lon;
          if(!mlat||!mlng) return null;
          const dx=(mlng-lng)*R*Math.cos(lat*Math.PI/180);
          const dy=(mlat-lat)*R;
          return{id:e.id,name:e.tags?.name||e.tags?.["name:ar"]||"مسجد",
            lat:mlat,lng:mlng,dist:Math.round(Math.sqrt(dx*dx+dy*dy))};
        }).filter(Boolean).sort((a,b)=>a.dist-b.dist).slice(0,15);
        setMosques(list);
        setLoading(false);
      })
      .catch(e=>{if(e.name!=="AbortError"){setFetchError("تعذّر تحميل المساجد");setLoading(false);}});
    return()=>ctrl.abort();
  },[lat,lng]);

  // Init map (only when Leaflet ready + div mounted + not already created)
  useEffect(()=>{
    if(mapStatus!=="ready"||!mapRef.current||!lat||!lng) return;
    if(mapInstRef.current){
      mapInstRef.current.setView([lat,lng],15);
      return;
    }
    const L=window.L;
    const m=L.map(mapRef.current,{zoomControl:true,attributionControl:false}).setView([lat,lng],15);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19}).addTo(m);
    L.circleMarker([lat,lng],{radius:9,fillColor:"#c9a227",color:"#fff",weight:2.5,fillOpacity:1})
      .addTo(m).bindPopup("📍 موقعك");
    mapInstRef.current=m;
    // Fix potential tile rendering issue after opacity transition
    setTimeout(()=>m.invalidateSize(),350);
  },[mapStatus,lat,lng]);

  // Add/refresh mosque markers (clear old first)
  useEffect(()=>{
    if(!mapInstRef.current||!mosques.length||mapStatus!=="ready") return;
    const L=window.L;
    // Remove previous mosque markers
    markersRef.current.forEach(mk=>mk.remove());
    markersRef.current=[];
    const icon=L.divIcon({html:`<div style="font-size:20px;line-height:1;filter:drop-shadow(0 1px 2px rgba(0,0,0,.4))">🕌</div>`,
      className:"",iconAnchor:[10,20]});
    const newMarkers=mosques.map(m=>{
      const mk=L.marker([m.lat,m.lng],{icon})
        .addTo(mapInstRef.current)
        .bindPopup(`<div style="font-family:serif;direction:rtl;text-align:right"><b>${m.name}</b><br/><small style="color:#666">${m.dist<1000?m.dist+"م":+(m.dist/1000).toFixed(1)+"كم"}</small></div>`);
      return mk;
    });
    markersRef.current=newMarkers;
  },[mosques,mapStatus]);

  const isReady=mapStatus==="ready";
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",minHeight:0}}>
      {/* Status bar (above map, not inside it) */}
      {(!isReady||loading||fetchError)&&(
        <div style={{margin:"6px 12px 0",padding:"10px 14px",borderRadius:10,
          background:T.card2,border:`1px solid ${T.bdr}`,textAlign:"center",flexShrink:0}}>
          {mapStatus==="error"&&<p style={{color:T.sub,fontSize:13}}>⚠️ تعذّر تحميل مكتبة الخريطة</p>}
          {fetchError&&<p style={{color:T.sub,fontSize:13}}>⚠️ {fetchError}</p>}
          {!fetchError&&mapStatus!=="error"&&(
            <p style={{color:T.sub,fontSize:13}}>{!isReady?"⏳ جارٍ تحميل الخريطة…":"🔍 جارٍ البحث عن المساجد…"}</p>
          )}
        </div>
      )}
      {/* Map div — always rendered so ref attaches */}
      <div ref={mapRef} style={{height:250,borderRadius:12,overflow:"hidden",
        border:`1px solid ${T.bdr}`,margin:"6px 12px 0",flexShrink:0,
        background:T.card2,opacity:isReady?1:0,transition:"opacity .3s"}}/>
      {/* Mosque list */}
      <div style={{flex:1,overflowY:"auto",padding:"8px 12px 4px"}}>
        {!loading&&!fetchError&&mosques.length===0&&isReady&&(
          <p style={{textAlign:"center",color:T.sub,padding:20,fontSize:14}}>لم يُعثر على مساجد قريبة (3 كم)</p>
        )}
        {mosques.map(m=>(
          <div key={m.id} onClick={()=>{
            mapInstRef.current?.setView([m.lat,m.lng],17);
            // open matching popup
            markersRef.current.find(mk=>mk.getLatLng().lat===m.lat)?.openPopup();
          }} style={{display:"flex",alignItems:"center",justifyContent:"space-between",
            padding:"9px 12px",borderRadius:10,marginBottom:5,cursor:"pointer",
            background:T.card,border:`1px solid ${T.bdr}`,animation:"fadeUp .3s ease"}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:20}}>🕌</span>
              <p style={{color:T.text,fontSize:14,direction:"rtl"}}>{m.name}</p>
            </div>
            <span style={{color:T.gold,fontSize:12,fontWeight:"bold",flexShrink:0,
              background:T.fill,border:`1px solid ${T.bdr}`,padding:"2px 8px",borderRadius:12}}>
              {m.dist<1000?`${m.dist}م`:`${(m.dist/1000).toFixed(1)}كم`}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   QIBLA TAB  (Qibla + Mosque Map)
══════════════════════════════════════════════════════ */
function QiblaTab(){
  const{T}=useT();
  const[st,setSt]=useState({s:"idle"});
  const[hdg,setHdg]=useState(0);
  const sRef=useRef(null);
  const[subTab,setSubTab]=useState("compass"); // compass | mosques

  const[needSensorPerm,setNeedSensorPerm]=useState(false);

  const setupSensor=useCallback(()=>{
    const fn=e=>{
    const raw=e.webkitCompassHeading??(e.alpha!=null?(360-e.alpha):0);
    setHdg(prev=>{
      // أقصر مسار بين زاويتَين (لتجنب القفز من 359→1)
      let diff=((raw-prev)+540)%360-180;
      return prev+diff*0.25; // تخفيف 25%
    });
  };
    sRef.current=fn;
    if(typeof DeviceOrientationEvent!=="undefined"&&typeof DeviceOrientationEvent.requestPermission==="function"){
      // iOS: must be called from user gesture
      setNeedSensorPerm(true);
    }else{
      window.addEventListener("deviceorientationabsolute",fn,true);
      window.addEventListener("deviceorientation",fn,true);
    }
  },[]);

  const requestSensorPermission=async()=>{
    try{
      const p=await DeviceOrientationEvent.requestPermission();
      if(p==="granted"&&sRef.current){
        window.addEventListener("deviceorientationabsolute",sRef.current,true);
        window.addEventListener("deviceorientation",sRef.current,true);
      }
      setNeedSensorPerm(false);
    }catch(e){setNeedSensorPerm(false);}
  };

  const onLoc=useCallback((data)=>{
    const q=qiblaDir(data.lat,data.lng), km=kmMecca(data.lat,data.lng);
    setSt({s:"ok",q,km,city:data.city||"",lat:data.lat,lng:data.lng});
    setupSensor();
  },[setupSensor]);

  const{locSt,detect,selectCity:selectLocCity,clearAndRefresh:clearLocRefresh}=useLocation(onLoc);
  const[showManualQ,setShowManualQ]=useState(false);

  useEffect(()=>{
    const cached=S.get("geoCache",null);
    if(cached) detect();
    return()=>{if(sRef.current){
      window.removeEventListener("deviceorientationabsolute",sRef.current,true);
      window.removeEventListener("deviceorientation",sRef.current,true);
    }};
  },[detect]);

  const isLoading=locSt.s==="loading"&&st.s!=="ok";
  if(isLoading) return <div style={{flex:1}}><Spin label="جارٍ تحديد الموقع…"/></div>;

  if(st.s!=="ok") return(
    <div style={{flex:1,display:"flex",flexDirection:"column",minHeight:0}}>
      <GpsPermissionScreen T={T}
        denied={locSt.s==="denied"||locSt.s==="no-geo"}
        onAllow={clearLocRefresh}
        onManual={()=>setShowManualQ(true)}/>
      <Sheet open={showManualQ} onClose={()=>setShowManualQ(false)} title="اختر موقعك">
        <CityPicker onSelect={c=>{selectLocCity(c);setShowManualQ(false);}}/>
      </Sheet>
    </div>
  );

  const O=135,needle=st.q-hdg;
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",minHeight:0,overflow:"hidden"}}>
      {/* Sub-tabs: القبلة | المساجد */}
      <div style={{display:"flex",margin:"10px 12px 0",borderRadius:12,overflow:"hidden",
        border:`1px solid ${T.bdr}`,flexShrink:0}}>
        {[{id:"compass",l:"🧭 القبلة"},{id:"mosques",l:"🕌 المساجد القريبة"}].map(s=>(
          <button key={s.id} onClick={()=>setSubTab(s.id)} style={{
            flex:1,padding:"9px 8px",border:"none",cursor:"pointer",fontSize:13,
            background:subTab===s.id?T.fill:"transparent",
            color:subTab===s.id?T.gold:T.sub,fontWeight:subTab===s.id?"bold":"normal",
            borderRight:s.id==="compass"?`1px solid ${T.bdr}`:"none"
          }}>{s.l}</button>
        ))}
      </div>

      {/* Location info strip */}
      <div style={{margin:"8px 12px 0",background:T.card,border:`1px solid ${T.bdr}`,
        borderRadius:10,padding:"8px 12px",display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0}}>
        <div style={{direction:"rtl"}}>
          {st.city&&<span style={{color:T.sub,fontSize:12}}>📍 {st.city} • </span>}
          <span style={{color:T.gold,fontSize:12}}>{st.km.toLocaleString("ar-SA")} كم من مكة</span>
        </div>
        <button onClick={()=>setShowManualQ(true)} style={{
          background:T.fill,border:`1px solid ${T.bdr}`,color:T.gold,
          borderRadius:8,padding:"4px 9px",cursor:"pointer",fontSize:11,flexShrink:0}}>
          تغيير
        </button>
      </div>
      <Sheet open={showManualQ} onClose={()=>setShowManualQ(false)} title="اختر موقعك">
        <CityPicker onSelect={c=>{selectLocCity(c);setShowManualQ(false);}}/>
      </Sheet>

      {/* Mosque map sub-tab */}
      {subTab==="mosques"&&<MosqueMap lat={st.lat||null} lng={st.lng||null}/>}

      {/* Compass sub-tab */}
      {subTab==="compass"&&<div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"center",padding:"10px 14px 8px",gap:12}}>
      <svg viewBox="0 0 270 270" width={260} height={260} style={{overflow:"visible"}}>
        <defs>
          <radialGradient id="rqg" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={T.card2}/>
            <stop offset="100%" stopColor={T.card}/>
          </radialGradient>
          <filter id="qgf" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="2.5" result="b"/>
            <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>
        <circle cx={O} cy={O} r={132} fill="url(#rqg)" stroke={T.bdr} strokeWidth="1.5"/>
        <circle cx={O} cy={O} r={114} fill="none" stroke={T.fill} strokeWidth={5} strokeDasharray="3 5"/>
        {Array.from({length:72},(_,i)=>i*5).map(deg=>{
          const r=(deg-90)*Math.PI/180,mj=deg%45===0,r1=mj?84:91;
          return<line key={deg} x1={O+r1*Math.cos(r)} y1={O+r1*Math.sin(r)}
            x2={O+98*Math.cos(r)} y2={O+98*Math.sin(r)} stroke={mj?T.gold:T.bdr} strokeWidth={mj?1.4:.6}/>;
        })}
        {[{a:0,l:"ش"},{a:90,l:"ق"},{a:180,l:"ج"},{a:270,l:"غ"}].map(({a,l})=>{
          const r=(a-90)*Math.PI/180;
          return<text key={l} x={O+107*Math.cos(r)} y={O+107*Math.sin(r)+5}
            textAnchor="middle" fontSize={a===0?13:10} fontFamily="'Amiri',serif"
            fontWeight="bold" fill={a===0?T.gold:T.dim}>{l}</text>;
        })}
        <g transform={`rotate(${needle},${O},${O})`} style={{transition:"transform .1s ease-out"}}>
          <polygon points={`${O},48 ${O+5},${O} ${O},${O+18} ${O-5},${O}`} fill={T.gold} filter="url(#qgf)"/>
          <polygon points={`${O},222 ${O+5},${O} ${O},${O-18} ${O-5},${O}`} fill={T.dim}/>
          <circle cx={O} cy={O} r={8} fill={T.card2} stroke={T.gold} strokeWidth="2"/>
          <circle cx={O} cy={O} r={3} fill={T.gold}/>
          <text x={O} y={34} textAnchor="middle" fontSize="17" style={{filter:`drop-shadow(0 0 4px ${T.gold})`}}>🕋</text>
        </g>
      </svg>
      <div style={{background:T.card,border:`1px solid ${T.bdr}`,borderRadius:11,padding:"10px 36px",textAlign:"center"}}>
        <p style={{color:T.sub,fontSize:11,marginBottom:2}}>اتجاه القبلة</p>
        <p style={{color:T.gold,fontSize:30,fontWeight:"bold"}}>{Math.round(st.q)}°</p>
      </div>
      {needSensorPerm&&(
        <button onClick={requestSensorPermission} style={{
          background:T.fill,border:`1px solid ${T.gold}`,color:T.gold,
          borderRadius:10,padding:"8px 20px",cursor:"pointer",fontSize:14}}>
          📡 تفعيل البوصلة (iOS)
        </button>
      )}
      <p style={{color:T.dim,fontSize:12,textAlign:"center"}}>وجِّه هاتفك حتى تشير الإبرة الذهبية نحو 🕋</p>
      </div>}  {/* end compass sub-tab */}
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   ROOT APP
══════════════════════════════════════════════════════ */
const TABS=[{id:"quran",l:"القرآن",ic:"📖"},{id:"adhkar",l:"الأذكار",ic:"📿"},{id:"prayer",l:"الصلاة",ic:"🕌"},{id:"qibla",l:"القبلة",ic:"🧭"}];
const TITLES={quran:"المصحف الكريم",adhkar:"الأذكار",prayer:"أوقات الصلاة",qibla:"القبلة والمساجد"};

const StarIco=()=>{const{T}=useT();return(
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <polygon points="12,2 14.5,9 22,9 16,14 18.5,21 12,17 5.5,21 8,14 2,9 9.5,9"
      fill="none" stroke={T.gold} strokeWidth="1" strokeLinejoin="round"/>
    <circle cx="12" cy="12" r="3" fill={T.gold} opacity=".25"/>
  </svg>
);};

// Auto dark: night 19:00–06:00, unless user overrode manually (stable, outside component)
function getAutoDark(){
  const saved=S.get("dark",null);
  if(saved!==null) return !!saved;
  const h=new Date().getHours();
  return h>=19||h<6;
}

export default function App(){
  const[dark,setDark]=useState(getAutoDark);

  // Auto-reset user override at midnight
  useEffect(()=>{
    const msToMidnight=()=>{const n=new Date();return new Date(n.getFullYear(),n.getMonth(),n.getDate()+1)-n;};
    const tid=setTimeout(()=>{ S.set("dark",null); },msToMidnight()); // reset override at midnight
    return()=>clearTimeout(tid);
  },[]);
  const toggleDark=()=>{const v=!dark;setDark(v);S.set("dark",v);};

  const T=dark?THEMES.dark:THEMES.light;
  const[tab,setTab]=useState("quran");

  const css=globalCss+`body{background:${T.bg};color:${T.text}}::-webkit-scrollbar-thumb{background:${T.bdr}}`;

  return(
    <Ctx.Provider value={{dark,T,setDark}}>
      <style>{css}</style>
      <svg style={{position:"fixed",inset:0,width:"100%",height:"100%",opacity:dark?.04:.06,pointerEvents:"none",zIndex:0}}>
        <defs>
          <pattern id="bgp2" width="80" height="80" patternUnits="userSpaceOnUse">
            <g fill="none" stroke={T.gold} strokeWidth=".45">
              <polygon points="40,7 46,28 66,28 50,40 56,61 40,49 24,61 30,40 14,28 34,28"/>
              <polygon points="40,18 44,28 54,28 46,35 49,46 40,40 31,46 34,35 26,28 36,28" opacity=".5"/>
            </g>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#bgp2)"/>
      </svg>

      <div style={{position:"fixed",inset:0,zIndex:1,display:"flex",flexDirection:"column",
        background:T.gradBg,maxWidth:480,left:"50%",transform:"translateX(-50%)",width:"100%"}}>

        {/* header */}
        <div style={{flexShrink:0,padding:"12px 16px 9px",
          background:T.overlay,zIndex:2}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:7}}>
            <button onClick={toggleDark} style={{background:T.fill,border:`1px solid ${T.bdr}`,
              borderRadius:20,padding:"4px 10px",cursor:"pointer",fontSize:15,color:T.gold}}>
              {dark?"☀️":"🌙"}
            </button>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <StarIco/>
              <h1 style={{fontSize:18,letterSpacing:2,
                background:`linear-gradient(135deg,${T.goldL},${T.gold},${T.goldD})`,
                WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
                {TITLES[tab]}
              </h1>
              <StarIco/>
            </div>
            <div style={{width:52}}/>
          </div>
          <div style={{height:1,background:`linear-gradient(to right,transparent,${T.bdr},transparent)`}}/>
        </div>

        {/* content */}
        <div style={{flex:1,display:"flex",flexDirection:"column",minHeight:0,overflow:"hidden"}}>
          <div key={tab} style={{flex:1,display:"flex",flexDirection:"column",minHeight:0,animation:"fadeUp .2s ease"}}>
            {tab==="quran"  &&<QuranTab/>}
            {tab==="adhkar" &&<AdhkarTab/>}
            {tab==="prayer" &&<PrayerTab/>}
            {tab==="qibla"  &&<QiblaTab/>}
          </div>
        </div>

        {/* bottom nav */}
        <div style={{flexShrink:0,display:"flex",padding:"7px 0 env(safe-area-inset-bottom,13px)",zIndex:2,
          background:T.overlay,borderTop:`1px solid ${T.bdr}`}}>
          {TABS.map(t=>{
            const on=t.id===tab;
            return(
              <button key={t.id} onClick={()=>setTab(t.id)} style={{
                flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2,
                background:"transparent",border:"none",cursor:"pointer",padding:"5px 0",position:"relative"}}>
                {on&&<div style={{position:"absolute",top:-7,left:"50%",transform:"translateX(-50%)",
                  width:28,height:2,borderRadius:1,background:`linear-gradient(to right,${T.goldD},${T.gold},${T.goldD})`}}/>}
                <span style={{fontSize:20,filter:on?`drop-shadow(0 0 4px ${T.gold})`:"none"}}>{t.ic}</span>
                <span style={{fontSize:10,color:on?T.gold:T.dim,fontWeight:on?"bold":"normal"}}>{t.l}</span>
              </button>
            );
          })}
        </div>
      </div>
    </Ctx.Provider>
  );
}
