/* ══════════════════════════════════════
   روحاني — Service Worker v2.0
   Cache-First + Network Fallback
══════════════════════════════════════ */
const CACHE  = 'ruhani-v2';
const STATIC = [
  './',
  './index.html',
  './app.jsx',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

// لا نخزن مؤقتاً هذه المصادر (تحتاج شبكة دائماً)
const SKIP = [
  'api.anthropic.com',
  'alquran.cloud',
  'islamic.network',
  'api.aladhan.com',
  'ip-api.com',
  'nominatim.openstreetmap.org',
  'unpkg.com',
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'openstreetmap.org/tiles',
  'tile.openstreetmap',
];

// ══ Install ══
self.addEventListener('install', e => {
  console.log('[SW] install');
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(STATIC)).then(() => self.skipWaiting())
  );
});

// ══ Activate ══
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// ══ Fetch ══
self.addEventListener('fetch', e => {
  const url = e.request.url;

  // تجاوز المصادر التي تحتاج شبكة
  if (SKIP.some(s => url.includes(s))) return;

  // POST requests — لا نخزنها
  if (e.request.method !== 'GET') return;

  // chrome-extension وغيرها
  if (!url.startsWith('http')) return;

  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(res => {
        if (!res || res.status !== 200 || res.type === 'opaque') return res;
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return res;
      }).catch(() => caches.match('./index.html'));
    })
  );
});

// ══ Push Notifications (للأذان) ══
self.addEventListener('push', e => {
  const data = e.data ? e.data.json() : {};
  self.registration.showNotification(data.title || '🕌 وقت الصلاة', {
    body: data.body || '',
    icon: './icons/icon-192.png',
    badge: './icons/icon-96.png',
    vibrate: [200, 100, 200, 100, 200],
    requireInteraction: true,
    tag: data.tag || 'prayer',
    dir: 'rtl',
    lang: 'ar',
  });
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow('./'));
});
