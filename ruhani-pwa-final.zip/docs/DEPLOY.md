# روحاني — دليل النشر الكامل

## محتويات الحزمة
```
www/
├── index.html      ← الصفحة الرئيسية
├── app.jsx         ← التطبيق كاملاً (~2500 سطر)
├── manifest.json   ← إعدادات PWA
├── sw.js           ← Service Worker (تخزين مؤقت)
└── icons/          ← أيقونات 72px → 512px
```

---

## 1. نشر على الويب (GitHub Pages) ← مجاني

### الخطوات:
1. افتح https://github.com → New Repository
2. اسمه: `ruhani` ← عام (Public)
3. ارفع جميع ملفات مجلد `www/`
4. Settings → Pages → Branch: main → Folder: / (root)
5. التطبيق يعمل على: `https://اسمك.github.io/ruhani`

### نقاط مهمة:
- HTTPS مُدار تلقائياً (ضروري لـ GPS و Notifications)
- التحديث: ارفع app.jsx الجديد فقط
- إذا أردت نطاق خاص: أضف CNAME مع نطاقك

---

## 2. Google Play Store ← عبر PWABuilder (مجاني)

### المتطلبات:
- التطبيق يعمل على HTTPS (GitHub Pages ✅)
- حساب Google Play Developer ($25 مرة واحدة)

### الخطوات:
1. افتح https://www.pwabuilder.com
2. أدخل رابط GitHub Pages
3. اضغط Package for stores → Android
4. حمّل ملف `ruhani.apk` أو `ruhani.aab`
5. ارفعه على Google Play Console
   - Internal Testing أولاً
   - ثم Production

### بديل (Bubblewrap):
```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest https://اسمك.github.io/ruhani/manifest.json
bubblewrap build
# → app-release-signed.apk جاهز للرفع
```

---

## 3. Apple App Store ← عبر PWABuilder

### المتطلبات:
- Apple Developer Account ($99/سنة)
- جهاز Mac أو Xcode Cloud

### الخطوات:
1. https://www.pwabuilder.com → iOS Package
2. افتح الـ .zip بـ Xcode
3. Product → Archive → Distribute App
4. App Store Connect → رفع

### بديل (Capacitor على Mac):
```bash
npm install -g @capacitor/cli
npx cap init روحاني com.ruhani.quran
npx cap add ios
npx cap copy
npx cap open ios
# ← Xcode يفتح → Archive → Upload
```

---

## 4. APK مباشر (Android) ← بدون Play Store

### استخدام Capacitor:
```bash
# متطلبات: Node.js + Android Studio + JDK 17
npm install -g @capacitor/cli
mkdir ruhani-app && cd ruhani-app
npm init -y
npm install @capacitor/core @capacitor/android

# انسخ مجلد www/ هنا
npx cap init "روحاني" "com.ruhani.quran" --web-dir www
npx cap add android
npx cap copy android
npx cap open android

# Android Studio → Build → Generate Signed APK
```

---

## 5. Samsung Galaxy Store ← مجاني

1. رفع نفس APK الخاص بـ Play Store
2. https://seller.samsungapps.com
3. New App → Android APK

---

## 6. Huawei AppGallery

1. https://developer.huawei.com/consumer/en/appgallery
2. رفع نفس AAB من Play Store

---

## نصائح قبل الرفع

### اختبار PWA:
```
Lighthouse (Chrome DevTools) → نسبة PWA يجب > 90%
```

### متطلبات Play Store:
- أيقونة 512×512 ← موجودة ✅
- لقطات شاشة (2-8 صور) ← خذها من الجوال
- وصف التطبيق (عربي + إنجليزي)
- Privacy Policy ← ضروري

### نموذج Privacy Policy (بسيط):
```
This app does not collect or store any personal data on external servers.
Location data is used only locally to calculate prayer times and Qibla direction.
No data is shared with third parties.
```

---

## تحديث التطبيق

### للويب (GitHub Pages):
1. عدّل app.jsx
2. ارفعه على GitHub
3. المستخدمون يحصلون على التحديث تلقائياً (Service Worker)

### للـ Play Store:
1. عدّل versionCode و versionName في capacitor.config.json
2. أعد بناء APK
3. ارفع APK الجديد على Play Console

---

## روابط مفيدة

- PWABuilder: https://www.pwabuilder.com
- Play Console: https://play.google.com/console
- App Store Connect: https://appstoreconnect.apple.com
- Bubblewrap CLI: https://github.com/GoogleChromeLabs/bubblewrap
- Capacitor: https://capacitorjs.com
